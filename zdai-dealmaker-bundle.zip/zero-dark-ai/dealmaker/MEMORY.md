# MEMORY.md — Agent Memory

> This file is your agent's long-term brain. Pre-seeded with smart defaults for salespeople and closers.
> Fill in the [BRACKETED] sections after completing your USER.md.
> Your agent will continue adding to this file automatically as it learns your preferences.

---

## Business Context
- **Company:** [BUSINESS NAME]
- **Owner/Rep:** [OWNER NAME]
- **What we sell:** [PRODUCT OR SERVICE]
- **Average deal size:** [AMOUNT]
- **Sales cycle:** [LENGTH]
- **Close rate (current):** [%]

## Active Pipeline
| Deal / Company | Contact | Stage | Value | Last Touch | Next Step | Days in Stage |
|----------------|---------|-------|-------|-----------|-----------|---------------|
| | | | | | | |

## Deal Stages
1. Prospect identified
2. First contact made
3. Discovery call completed
4. Demo / pitch delivered
5. Proposal sent
6. Negotiation
7. Closed Won / Closed Lost

## Follow-Up Rules
- **No response after 48 hours:** send follow-up #1 (light touch — add value)
- **No response after 5 days:** send follow-up #2 (different angle)
- **No response after 10 days:** breakup email — leave door open
- **Deal quiet for 5+ days:** FLAG for owner review
- **Closed Lost:** log the reason and ask for referral 30 days later

## Ideal Customer Profile
- **Target titles:** [e.g. VP Sales, Founder, Head of Ops]
- **Target company size:** [employees / revenue range]
- **Target industries:** [industries]
- **Pain points we solve:** [PAIN POINTS]
- **Red flags (bad fit):** [e.g. too small, wrong budget, wrong timeline]

## Owner Preferences
- **Proposal style:** [brief and punchy / detailed and thorough]
- **Things to never include in proposals:** [e.g. competitor names, specific SLAs]
- **Tone in outreach:** [e.g. casual, consultative, direct]
- **[ADD YOUR OWN RULES HERE]**

---

## Pre-Seeded Best Practices (Sales & Deal Closing)

### Outreach That Gets Replies
- Subject lines that work: questions, relevance, name-drop a shared connection
- First email: problem → why you → one CTA. Max 5 sentences.
- Personalization matters: reference something specific about them, not your generic pitch
- Video DMs on LinkedIn outperform text by 3:1 for cold outreach

### Discovery Calls
- Let them talk 70% of the time — you're mining for pain, not pitching
- Best discovery questions: "What's the cost of not solving this?", "What's tried and failed?"
- Always end with: "What does your decision process look like from here?"
- No next step = no deal — close for the meeting, not the sale

### Proposals
- Lead with their problem in their language — show you listened
- Keep it to 3 options (good / better / best) — choice without overwhelm
- One clear CTA: "I'll hold this pricing for 7 days"
- Proposals sent Friday die — send Monday–Wednesday

### Closing
- Best close: "Is there anything preventing us from moving forward today?"
- Silence is a tool — ask for the close, then shut up
- The first no is usually a question disguised as a no
- Always know: budget / authority / need / timeline (BANT) before proposing

---

*Last updated: [auto-updated by agent]*
