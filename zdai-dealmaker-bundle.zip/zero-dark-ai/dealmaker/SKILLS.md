# SKILLS.md — The Dealmaker Skill Bundle

> These 7 skills ship with every copy of The Dealmaker. Selected for sales reps, closers, and revenue-focused operators.
> Install script handles installation automatically.

---

## Bundled Skills

### 1. `content-creator`
**Why it's included:** Proposals, follow-up sequences, cold outreach, and pitch decks — all written in your voice, fast. The closer's secret weapon for written communication.  
**Sales use case:** "Write a 5-touch cold email sequence for SaaS decision-makers in logistics" or "Draft a proposal for a $25K managed services contract — keep it tight and punchy."

---

### 2. `summarize`
**Why it's included:** Research prospects before every call. Summarize long contracts, meeting notes, and competitor analyses in seconds.  
**Sales use case:** "Summarize everything public about Acme Corp — what do they do, what might they need, what's their pain?" or "Pull the key points from this 8-page RFP."

---

### 3. `apple-reminders`
**Why it's included:** Deals die from inaction, not objections. Never miss a follow-up, callback, or check-in again.  
**Sales use case:** "Remind me to follow up with Baker Industries on Thursday" or "Set a reminder every Friday to review my pipeline and flag any deals that haven't moved."

---

### 4. `nano-banana-pro`
**Why it's included:** Produce professional visuals for proposals, pitch decks, LinkedIn content, and sales collateral — without a designer.  
**Sales use case:** "Create a clean, professional cover image for a proposal slide deck" or "Generate a LinkedIn banner that positions me as a sales consultant in the manufacturing space."

---

### 5. `weather`
**Why it's included:** In-person sales and field reps depend on weather for scheduling — and it's a natural conversation opener.  
**Sales use case:** "It's going to snow in Milwaukee — should I push the client visit to next week or confirm they'll still be in office?" 

---

### 6. `cmc-mcp`
**Why it's included:** Selling into crypto, fintech, or Web3? Real-time market data makes you the smartest person in the room when talking about deals in volatile markets.  
**Sales use case:** "My prospect mentioned their budget depends on their BTC holdings — what's the current market like?" or "Summarize the current crypto market sentiment for a financial services pitch."

---

### 7. `apple-notes`
**Why it's included:** Log call notes, deal intel, objection patterns, and client intel immediately. Every piece of insight goes into the system, never your head.  
**Sales use case:** "Save my notes from the Acme Corp discovery call" or "Log that Johnson at Baker hates SaaS annual contracts — he wants monthly flexibility."

---

## Installation

These are installed automatically by `install.sh`. To install manually:

```bash
# Global skills (pre-installed with OpenClaw):
# apple-reminders, apple-notes, summarize, weather, nano-banana-pro, cmc-mcp

# Workspace-local skills (copy from bundle):
cp -r ./skills/content-creator ~/.openclaw/workspace-YOUR-NAME/skills/
```

---

## Skills NOT Included (available as add-ons)

| Skill | Why it's an add-on |
|-------|-------------------|
| `seo-keyword-strategist` | Marketing-focused, less relevant for direct sales |
| `gog` | Google Workspace — useful add-on for calendar-heavy sales teams |
| `github` | Developer-focused |

> Add-on skills available at zerodarkAI.com/packs
