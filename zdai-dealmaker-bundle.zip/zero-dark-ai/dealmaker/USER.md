# USER.md — About You

> Fill this in. The more detail you provide, the smarter your agent gets from Day 1.

---

## Basic Info
- **Your name:** 
- **What to call you:** 
- **Timezone:** 
- **Primary contact method:** Discord / Telegram / Email

## Your Role & Business
- **Company name:** 
- **Your title:** (e.g. Account Executive, Founder, Sales Director)
- **What you sell:** (product, service, or SaaS)
- **Average deal size:** 
- **Average sales cycle length:** (days / weeks / months)
- **Industry you sell into:** 

## Your Pipeline
- **How many active deals are you working right now:** 
- **How do you currently track leads:** (CRM, spreadsheet, memory...)
- **Where do most of your leads come from:** 
- **Biggest drop-off point in your pipeline:** (prospecting / demo / proposal / close)
- **Close rate (rough estimate):** 

## Your Sales Process
- **Outreach method(s) you use:** (cold email, LinkedIn, referrals, inbound, etc.)
- **Typical deal stages you go through:** 
- **What does your proposal / pitch look like today:** 
- **How long do you wait before following up on silence:** 
- **Deals you're most proud of closing (what worked):** 

## Prospects & Targets
- **Ideal customer profile (who you're hunting):** 
- **Decision maker title(s) you typically sell to:** 
- **Geographic focus (local / national / global):** 
- **Industries you focus on:** 

## Goals
- **Revenue goal (next 90 days):** 
- **Number of deals you want to close next quarter:** 
- **Biggest gap between where you are and hitting quota:** 
- **What would make this agent 10x valuable to you:** 

## Working Hours
- **Active selling hours:** 
- **Days off:** 
- **Things you NEVER want the agent to do:** 
