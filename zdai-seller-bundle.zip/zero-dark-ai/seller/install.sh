#!/usr/bin/env bash
# ============================================================
# Zero Dark AI — The Seller — Install Script v1.1
# ============================================================
# Installs your AI seller agent into OpenClaw workspace.
# Run: bash install.sh
# ============================================================

set -euo pipefail

# ── Colors ──────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ── Helpers ─────────────────────────────────────────────────
log()    { echo -e "${CYAN}▶${NC} $*"; }
ok()     { echo -e "${GREEN}✓${NC} $*"; }
warn()   { echo -e "${YELLOW}⚠${NC}  $*"; }
error()  { echo -e "${RED}✗ ERROR:${NC} $*" >&2; }
section(){ echo -e "\n${BOLD}$*${NC}"; }

# ── Script location (source files live next to this script) ──
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Banner ──────────────────────────────────────────────────
echo ""
echo -e "${BOLD}╔══════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║   Zero Dark AI — The Seller Installer    ║${NC}"
echo -e "${BOLD}║              v1.1                        ║${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── Step 1: Find OpenClaw workspace ─────────────────────────
section "Step 1/5 — Locating OpenClaw workspace..."

WORKSPACE=""

# Check common default locations
for candidate in \
    "$HOME/.openclaw/workspace" \
    "$HOME/.openclaw/workspace-default" \
    "$HOME/.openclaw/workspaces/default"; do
    if [[ -d "$candidate" ]]; then
        WORKSPACE="$candidate"
        ok "Found workspace at: $WORKSPACE"
        break
    fi
done

# If not found, check if openclaw CLI can tell us
if [[ -z "$WORKSPACE" ]] && command -v openclaw &>/dev/null; then
    DETECTED=$(openclaw config get workspace.path 2>/dev/null || true)
    if [[ -n "$DETECTED" && -d "$DETECTED" ]]; then
        WORKSPACE="$DETECTED"
        ok "Found workspace via openclaw config: $WORKSPACE"
    fi
fi

# Still not found — ask the user
if [[ -z "$WORKSPACE" ]]; then
    warn "Could not auto-detect your OpenClaw workspace."
    echo ""
    echo "  Common locations:"
    echo "    Mac:   ~/.openclaw/workspace"
    echo "    Linux: ~/.openclaw/workspace"
    echo ""
    read -rp "  Enter your OpenClaw workspace path: " USER_WORKSPACE
    USER_WORKSPACE="${USER_WORKSPACE/#\~/$HOME}"  # expand tilde
    if [[ ! -d "$USER_WORKSPACE" ]]; then
        error "Path does not exist: $USER_WORKSPACE"
        echo "  Please create it first: mkdir -p \"$USER_WORKSPACE\""
        exit 1
    fi
    WORKSPACE="$USER_WORKSPACE"
    ok "Using workspace: $WORKSPACE"
fi

# ── Step 2: Collect info ─────────────────────────────────────
section "Step 2/5 — Tell us about your business..."
echo ""

read -rp "  Business name (e.g. 'Bloom Candle Co'): " BUSINESS_NAME
if [[ -z "$BUSINESS_NAME" ]]; then
    error "Business name cannot be empty."
    exit 1
fi

read -rp "  Your first name (e.g. 'Sarah'): " OWNER_NAME
if [[ -z "$OWNER_NAME" ]]; then
    error "Owner name cannot be empty."
    exit 1
fi

read -rp "  Your timezone (e.g. 'America/Chicago'): " TIMEZONE
TIMEZONE="${TIMEZONE:-America/Chicago}"

echo ""
ok "Got it. Installing for: $BUSINESS_NAME / $OWNER_NAME / $TIMEZONE"

# ── Step 3: Set up agent directory ───────────────────────────
section "Step 3/5 — Installing agent files..."

# Sanitize business name for directory (lowercase, spaces → hyphens)
DIR_NAME="the-seller"
DEST_DIR="${WORKSPACE}/${DIR_NAME}"

if [[ -d "$DEST_DIR" ]]; then
    warn "Directory already exists: $DEST_DIR"
    read -rp "  Overwrite? (y/N): " CONFIRM
    if [[ "$(echo "$CONFIRM" | tr '[:upper:]' '[:lower:]')" != "y" ]]; then
        echo "  Installation cancelled."
        exit 0
    fi
fi

mkdir -p "$DEST_DIR"
ok "Created: $DEST_DIR"

# Files to install from agent/ subfolder (if exists) or same directory
SOURCE_AGENT_DIR="${SCRIPT_DIR}/agent"
if [[ ! -d "$SOURCE_AGENT_DIR" ]]; then
    SOURCE_AGENT_DIR="$SCRIPT_DIR"
fi

# Copy and token-replace each core file
install_file() {
    local src="$1"
    local dest_name="$2"

    if [[ ! -f "$src" ]]; then
        warn "Source file not found, skipping: $src"
        return
    fi

    local dest="${DEST_DIR}/${dest_name}"

    # Replace tokens (use | as delimiter to avoid / conflicts in timezones/paths)
    sed \
        -e "s|\[BUSINESS NAME\]|${BUSINESS_NAME}|g" \
        -e "s|\[OWNER NAME\]|${OWNER_NAME}|g" \
        -e "s|\[TIMEZONE\]|${TIMEZONE}|g" \
        "$src" > "$dest"

    ok "Installed: $dest_name"
}

install_file "${SOURCE_AGENT_DIR}/SOUL.md"   "SOUL.md"
install_file "${SOURCE_AGENT_DIR}/USER.md"   "USER.md"
install_file "${SOURCE_AGENT_DIR}/MEMORY.md" "MEMORY.md"
install_file "${SOURCE_AGENT_DIR}/AGENTS.md" "AGENTS.md"

# ── Step 4: Install skills ───────────────────────────────────
section "Step 4/5 — Installing skills..."

# OpenClaw skills are either:
#   (A) Global — already installed system-wide in OpenClaw
#   (B) Workspace-local — bundled in this package, copied to your workspace
#
# No `openclaw skills install` command exists — skills live at two locations:
#   Global:    /opt/homebrew/lib/node_modules/openclaw/skills/<name>/
#   Workspace: ~/.openclaw/workspace-<name>/skills/<name>/

SKILLS_DIR="${WORKSPACE}/skills"
mkdir -p "$SKILLS_DIR"

# ── Global skills (pre-installed with OpenClaw) ──────────────
GLOBAL_SKILLS=(
    "nano-banana-pro"
    "summarize"
    "apple-reminders"
    "apple-notes"
    "weather"
)

# Common global skill directories to check
GLOBAL_SKILL_ROOTS=(
    "/opt/homebrew/lib/node_modules/openclaw/skills"
    "/usr/local/lib/node_modules/openclaw/skills"
    "/usr/lib/node_modules/openclaw/skills"
)

check_global_skill() {
    local skill="$1"
    for root in "${GLOBAL_SKILL_ROOTS[@]}"; do
        if [[ -d "${root}/${skill}" ]]; then
            echo "${root}/${skill}"
            return 0
        fi
    done
    return 1
}

for skill in "${GLOBAL_SKILLS[@]}"; do
    if skill_path=$(check_global_skill "$skill"); then
        ok "Global skill ready: $skill (${skill_path})"
    else
        warn "Global skill not found: $skill — may need OpenClaw reinstall"
    fi
done

# ── Workspace-local skills (bundled in this package) ─────────
# These skills are not distributed with OpenClaw core.
# They are bundled in this ZIP and installed to your workspace.

LOCAL_SKILLS_DIR="${SCRIPT_DIR}/skills"

LOCAL_SKILLS=(
    "content-creator"
    "seo-keyword-strategist"
)

for skill in "${LOCAL_SKILLS[@]}"; do
    src="${LOCAL_SKILLS_DIR}/${skill}"
    dest="${SKILLS_DIR}/${skill}"

    if [[ -d "$src" ]]; then
        if [[ -d "$dest" ]]; then
            warn "Skill already installed: $skill (overwriting)"
            rm -rf "$dest"
        fi
        cp -r "$src" "$dest"
        ok "Installed local skill: $skill → $dest"
    else
        warn "Bundled skill not found: $skill (expected at ${src})"
        warn "  This skill may be missing from the package — contact support@zerodarkAI.com"
    fi
done

# ── Step 5: Done ─────────────────────────────────────────────
section "Step 5/5 — Wrapping up..."

echo ""
echo -e "${GREEN}${BOLD}✅ Installation complete!${NC}"
echo ""
echo -e "${BOLD}Skills status:${NC}"
echo "  Global (pre-installed): nano-banana-pro, summarize, apple-reminders, apple-notes, weather"
echo "  Local (installed now):  content-creator, seo-keyword-strategist"
echo ""
echo -e "${BOLD}Your agent is installed at:${NC}"
echo "  $DEST_DIR"
echo ""
echo -e "${BOLD}Next steps:${NC}"
echo ""
echo "  1. Open SOUL.md and review your agent settings"
echo "     → $DEST_DIR/SOUL.md"
echo ""
echo "  2. Fill in USER.md with your business details"
echo "     → $DEST_DIR/USER.md"
echo ""
echo "  3. Update MEMORY.md with your products and brand voice"
echo "     → $DEST_DIR/MEMORY.md"
echo ""
echo "  4. Start your agent:"
echo "     → openclaw gateway start"
echo ""
echo "  5. Go to Discord and say hello to $BUSINESS_NAME's new AI assistant 🛒"
echo ""
echo -e "Need help? support@zerodarkAI.com | zerodarkAI.com"
echo ""
