# SKILLS.md — The Seller Skill Bundle

> These 7 skills ship with every copy of The Seller. They are selected specifically for e-commerce operators.
> Install script handles installation automatically.

---

## Bundled Skills

### 1. `content-creator`
**Why it's included:** The core content engine. Generates TikTok scripts, Instagram captions, product hooks, and campaign copy in any brand voice.  
**E-commerce use case:** "Write 10 TikTok hooks for my handmade candle line targeting women 25–40. Casual tone, short, conversion-focused."

---

### 2. `seo-keyword-strategist`
**Why it's included:** SEO is how listings get discovered. This skill generates keyword research and SEO-optimized titles, descriptions, and tags for Etsy, TikTok Shop, Shopify, and Amazon.  
**E-commerce use case:** "Give me the top 10 keywords for a soy candle seller on Etsy and rewrite my listing title to rank higher."

---

### 3. `nano-banana-pro`
**Why it's included:** Product photography is expensive. This skill generates high-quality AI product images — lifestyle shots, mockups, dark/light backgrounds — on demand.  
**E-commerce use case:** "Generate a product photo of a wooden wick candle on a marble surface, moody dark aesthetic, soft backlight."

---

### 4. `summarize`
**Why it's included:** Turns long-form research into actionable intelligence. Summarizes competitor listings, trend articles, YouTube videos, Reddit threads, and market reports.  
**E-commerce use case:** "Summarize this Amazon review thread for [competitor product] — what are customers complaining about?" or "What's this TikTok trend report saying in plain English?"

---

### 5. `apple-reminders`
**Why it's included:** Operations don't run on vibes. This skill creates reminders for filming days, restock deadlines, sale launches, and follow-ups — all via plain English commands.  
**E-commerce use case:** "Remind me Friday at 2pm to reorder wick supplies" or "Set a weekly reminder every Monday to check TikTok analytics."

---

### 6. `apple-notes`
**Why it's included:** Captures ideas, research, competitor intel, and product notes before they evaporate. Works alongside MEMORY.md for persistent knowledge.  
**E-commerce use case:** "Save this product idea to Notes: bamboo candle holders, trending on Pinterest, estimated COGs $3, retail $22."

---

### 7. `weather`
**Why it's included:** Content planning and product relevance are seasonal. Weather-aware agents write better, more timely scripts and flag when seasonal trends are incoming.  
**E-commerce use case:** "It's going to snow this weekend in Chicago — write me 3 TikTok scripts tying my cozy candle collection to the weather."

---

## Installation

These are installed automatically by `install.sh`. To install manually:

```bash
openclaw skills install content-creator
openclaw skills install seo-keyword-strategist
openclaw skills install nano-banana-pro
openclaw skills install summarize
openclaw skills install apple-reminders
openclaw skills install apple-notes
openclaw skills install weather
```

---

## Skills NOT Included (available as add-ons)

| Skill | Why it's an add-on |
|-------|-------------------|
| `gog` (Google Workspace) | Requires Google OAuth setup — not zero-friction for all users |
| `tmux` | Power-user only — advanced automation sessions |
| `github` | Developer-focused, not relevant for most sellers |
| `cmc-mcp` | Crypto market data — niche use case |

> Add-on skills available at zerodarkAI.com/packs
