# MEMORY.md — Agent Memory

> This file is your agent's long-term brain. It's pre-seeded with smart defaults for e-commerce sellers.
> Fill in the [BRACKETED] sections after completing your CLIENT-QUESTIONNAIRE.
> Your agent will continue adding to this file automatically as it learns your preferences.

---

## Business Context
- **Business:** [BUSINESS NAME]
- **Owner:** [OWNER NAME]
- **Products:** [PRODUCT DESCRIPTION]
- **Platforms:** [SALES PLATFORMS]
- **Niche keywords:** [e.g. "handmade soy candles", "cottagecore", "home fragrance"]
- **Price range:** [e.g. "$15–$45"]

## Brand Voice
- **Tone:** [e.g. Warm, casual, witty — like a knowledgeable friend, not a corporation]
- **Avoid:** [e.g. Corporate speak, excessive emojis, aggressive sales language]
- **Always:** [e.g. Lead with benefits, use "you" language, keep captions under 150 chars]
- **Sample caption they love:** [paste an example if you have one]

## Content Defaults
- **Script style:** Hook → Problem → Solution → CTA
- **Default CTA:** [e.g. "Link in bio 👆" / "Shop now in TikTok Shop" / "Comment SIZE for the link"]
- **Posting schedule:** [e.g. TikTok: daily 7pm | IG: 3x/week | Threads: daily]
- **Content approval required:** YES — always wait for 👍 before posting

## Competitor Watchlist
- [Competitor 1 — URL or name]
- [Competitor 2 — URL or name]
- [Competitor 3 — URL or name]

## Product Catalog (Top Items)
| Product | Price | Platform | Notes |
|---------|-------|----------|-------|
| [Product 1] | $ | | |
| [Product 2] | $ | | |
| [Product 3] | $ | | |

## Rules (Owner Preferences)
- Never post without explicit approval
- Never fabricate reviews, testimonials, or sales numbers
- Always flag if a trending product overlaps with current catalog
- [ADD YOUR OWN RULES HERE]

## Active Projects
- Content Rewards campaigns: [campaigns enrolled if any]
- Current promotions: [any active sales or promos]
- Restock reminders: [products running low]

---

## Pre-Seeded Best Practices (E-commerce Seller)

### TikTok Content That Converts
- Best performing hook format: "POV: you just discovered [product]..."
- Hook must land in first 2 seconds
- Show the product in use — not just sitting there
- UGC-style (casual, shot on phone) outperforms polished ads 3:1
- Strong CTAs: "comment X for the link", "check TikTok Shop", "link in bio"

### Product Listings (SEO)
- Title format: [Primary Keyword] | [Benefit] | [Secondary Keyword]
- First 2 sentences of description carry the most SEO weight
- Include size, material, use case in every listing
- 5–8 tags per listing, mix broad + long-tail

### Trending Product Research
- Check: TikTok Made Me Buy It hashtag, Amazon Movers & Shakers, Pinterest Trends
- Winning product signals: 3+ videos with 100K+ views in 30 days
- Avoid: saturated niches with 10K+ competing sellers at same price point

### Competitor Monitoring
- Check prices every 2 weeks minimum
- Flag if competitor adds new product in your category
- Watch their review velocity — sudden spike = new traffic source

---

*Last updated: [auto-updated by agent]*
