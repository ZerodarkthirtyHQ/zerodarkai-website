# USER.md — About You

> Fill this in. The more detail you provide, the smarter your agent gets from Day 1.

---

## Basic Info
- **Your name:** 
- **What to call you:** 
- **Timezone:** 
- **Primary contact method:** Discord / Telegram / Email

## Your Business
- **Business name:** 
- **What you sell:** 
- **Where you sell:** (TikTok Shop / Etsy / Shopify / Amazon / Other)
- **Store URL(s):** 
- **Monthly revenue (approx):** 
- **How long in business:** 

## Your Products
- **Top 3 best sellers:**
  1. 
  2. 
  3. 
- **Average product price:** 
- **Product niche/category:** 
- **Unique selling point (why customers buy from YOU vs competitors):** 

## Your Audience
- **Who buys from you (age, gender, interests):** 
- **What problem do your products solve for them:** 
- **Where do they hang out online:** 

## Content & Social
- **TikTok handle:** 
- **Instagram handle:** 
- **Other platforms:** 
- **How often do you post currently:** 
- **What content performs best for you:** 
- **What content you hate making:** 

## Competitors
- **Top 3 competitors (name or URL):**
  1. 
  2. 
  3. 
- **What they do better than you:** 
- **What you do better than them:** 

## Goals
- **Revenue goal (next 90 days):** 
- **Biggest bottleneck right now:** 
- **What would make this agent 10x valuable to you:** 

## Communication Preferences
- **How often do you want the agent to check in:** Daily / Weekly / Only when urgent
- **Preferred reply length:** Short & direct / Detailed & thorough
- **Things you NEVER want the agent to do:** 

## Working Hours
- **Active hours:** 
- **Days off:** 
- **Best time to receive morning brief:** 
