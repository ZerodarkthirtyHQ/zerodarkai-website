# Package Structure — The Seller v1.0

> This is the exact file layout for the deliverable ZIP sent to customers.
> Build script should produce: `zero-dark-the-seller-v1.0.zip`

---

```
zero-dark-the-seller-v1.0/
│
├── install.sh                    ← Run this first. Handles everything automatically.
├── INSTALL.md                    ← Step-by-step setup guide (human-readable)
├── WHAT-YOU-GOT.md               ← Full feature reference — skills, crons, channels
├── CLIENT-QUESTIONNAIRE.md       ← Intake form to fill out before launching
│
├── agent/
│   ├── SOUL.md                   ← Agent identity, personality, rules (Max)
│   ├── USER.md                   ← Template: owner fills in their business info
│   ├── MEMORY.md                 ← Pre-seeded e-commerce knowledge base
│   └── AGENTS.md                 ← Minimal bootstrapping instructions for the agent
│
└── skills/
    └── SKILLS.md                 ← The bundled skill list with descriptions
```

---

## File Descriptions

| File | Who reads it | Purpose |
|------|-------------|---------|
| `install.sh` | Installer (automated) | Sets up workspace, installs skills, tokens client info |
| `INSTALL.md` | New customer | Step-by-step guide, prereqs, troubleshooting |
| `WHAT-YOU-GOT.md` | New customer | Full feature list, cron schedule, channel map |
| `CLIENT-QUESTIONNAIRE.md` | New customer | Intake form — filled out before first session |
| `agent/SOUL.md` | Agent (Max) | Identity, mission, rules, brand voice template |
| `agent/USER.md` | Agent + customer | Customer info template — filled out during setup |
| `agent/MEMORY.md` | Agent (Max) | Pre-seeded e-commerce best practices + client slots |
| `agent/AGENTS.md` | Agent (Max) | Session startup + memory rules — minimal, solo operator |
| `skills/SKILLS.md` | Customer + installer | Documents what's installed and why |

---

## Build the ZIP (for internal use)

From the `zero-dark-ai/` directory:

```bash
# Assemble package folder
mkdir -p /tmp/zero-dark-the-seller-v1.0/agent
mkdir -p /tmp/zero-dark-the-seller-v1.0/skills

# Copy root files
cp seller/install.sh          /tmp/zero-dark-the-seller-v1.0/
cp INSTALL.md                 /tmp/zero-dark-the-seller-v1.0/
cp WHAT-YOU-GOT.md            /tmp/zero-dark-the-seller-v1.0/
cp CLIENT-QUESTIONNAIRE.md    /tmp/zero-dark-the-seller-v1.0/

# Copy agent files
cp seller/SOUL.md             /tmp/zero-dark-the-seller-v1.0/agent/
cp seller/USER.md             /tmp/zero-dark-the-seller-v1.0/agent/
cp seller/MEMORY.md           /tmp/zero-dark-the-seller-v1.0/agent/
cp seller/AGENTS.md           /tmp/zero-dark-the-seller-v1.0/agent/

# Copy skills manifest
cp seller/SKILLS.md           /tmp/zero-dark-the-seller-v1.0/skills/

# Zip it
cd /tmp
zip -r zero-dark-the-seller-v1.0.zip zero-dark-the-seller-v1.0/
echo "✓ Package ready: /tmp/zero-dark-the-seller-v1.0.zip"
```

---

## Pre-Ship Checklist

- [ ] No `[FILL IN]` placeholders remaining in SOUL.md
- [ ] INSTALL.md has zero "Gumroad" references  
- [ ] `install.sh` runs clean on fresh Mac (tested)
- [ ] `install.sh` runs clean on fresh Linux (tested)
- [ ] All 7 skills install without errors
- [ ] AGENTS.md is minimal — no Prison Mike roster or sub-agent rules
- [ ] WHAT-YOU-GOT.md has no Gumroad footer
- [ ] Version number consistent across all files (v1.0)
