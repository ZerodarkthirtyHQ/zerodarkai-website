# USER.md — About You

> Fill this in. The more detail you provide, the smarter your agent gets from Day 1.

---

## Basic Info
- **Your name:** 
- **What to call you:** 
- **Timezone:** 
- **Primary contact method:** Discord / Telegram / Email

## Your Business
- **Business name:** 
- **What service(s) do you provide:** 
- **Industry / niche:** (e.g. HVAC, landscaping, cleaning, consulting, coaching)
- **Business model:** (project-based / retainer / hourly / subscription)
- **Years in business:** 
- **Team size:** (just me / 2–5 / 5–20 / 20+)

## Your Clients
- **How many active clients do you manage at once:** 
- **Average client contract value:** 
- **Average project duration:** 
- **How do you currently find new clients:** 
- **Biggest client pain points you solve:** 

## Current Operations
- **Tools you use today:** (CRM, scheduling, invoicing, project management)
- **Biggest operational headache right now:** 
- **Where things fall through the cracks most often:** 
- **How much time per week do you spend on admin vs billable work:** 

## Scheduling & Capacity
- **How many client appointments/calls per week on average:** 
- **Do you use a booking tool? (Calendly, Acuity, etc.):** 
- **How far out do you book work:** 
- **Hardest thing to manage on your calendar:** 

## Communication
- **How often do you want client check-in reminders:** 
- **Do clients text, email, or call you most?:** 
- **How quickly do you aim to respond to clients:** 
- **Anything clients always ask that you wish was automated:** 

## Goals
- **Revenue goal (next 90 days):** 
- **Biggest bottleneck right now:** 
- **What would make this agent 10x valuable to you:** 

## Working Hours
- **Active hours:** 
- **Days off:** 
- **Things you NEVER want the agent to do:** 
