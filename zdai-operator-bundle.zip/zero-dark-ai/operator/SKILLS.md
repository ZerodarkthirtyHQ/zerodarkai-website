# SKILLS.md — The Operator Skill Bundle

> These 7 skills ship with every copy of The Operator. Selected for service business owners and ops-heavy roles.
> Install script handles installation automatically.

---

## Bundled Skills

### 1. `apple-reminders`
**Why it's included:** The backbone of operations. Never miss a follow-up, appointment, deadline, or restock — set reminders from plain English and let the agent handle the scheduling.  
**Ops use case:** "Remind me to follow up with Johnson & Sons on Wednesday at 10am" or "Set a weekly reminder every Monday to review the project pipeline."

---

### 2. `apple-notes`
**Why it's included:** Quick capture for client notes, meeting summaries, SOPs, and anything that needs to stay accessible across sessions.  
**Ops use case:** "Save these meeting notes to Apple Notes under 'Client: Acme Corp'" or "Create a note with the onboarding checklist for new clients."

---

### 3. `summarize`
**Why it's included:** Turns long emails, contracts, reports, and research into clear, actionable bullet points. Ops lives on information synthesis.  
**Ops use case:** "Summarize this client contract and flag any red flags" or "Pull the key action items from this 45-minute meeting transcript."

---

### 4. `weather`
**Why it's included:** Critical for field service businesses. Weather awareness drives scheduling, client communication, and crew deployment decisions.  
**Ops use case:** "Will it rain Thursday in Chicago? I need to decide whether to reschedule the exterior job" or "What's the 5-day forecast for our job site zip code?"

---

### 5. `gog` *(if available)*
**Why it's included:** Google Calendar integration for scheduling client appointments, blocking time, and syncing with team calendars.  
**Ops use case:** "Schedule a client kickoff for next Tuesday at 2pm and send a Calendar invite" or "What does my week look like? Any double-bookings?"

---

### 6. `content-creator`
**Why it's included:** Client proposals, follow-up emails, service descriptions, and business communications — all written in your voice without staring at a blank screen.  
**Ops use case:** "Write a professional follow-up email to a prospect who went quiet after our quote" or "Draft a service proposal for a new landscaping maintenance client."

---

### 7. `nano-banana-pro`
**Why it's included:** Produce professional marketing images for your service business — job site before/after visuals, social proof assets, and promotional graphics.  
**Ops use case:** "Create a before/after graphic template for our cleaning service portfolio" or "Generate a professional banner image for our Google Business profile."

---

## Installation

These are installed automatically by `install.sh`. To install manually:

```bash
# Global skills (pre-installed with OpenClaw):
# apple-reminders, apple-notes, summarize, weather, nano-banana-pro

# Workspace-local skills (copy from bundle):
cp -r ./skills/content-creator ~/.openclaw/workspace-YOUR-NAME/skills/
```

---

## Skills NOT Included (available as add-ons)

| Skill | Why it's an add-on |
|-------|-------------------|
| `cmc-mcp` | Crypto market data — not relevant for most service businesses |
| `github` | Developer-focused |
| `seo-keyword-strategist` | Better suited for e-commerce / content businesses |

> Add-on skills available at zerodarkAI.com/packs
