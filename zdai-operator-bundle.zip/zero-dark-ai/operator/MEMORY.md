# MEMORY.md — Agent Memory

> This file is your agent's long-term brain. Pre-seeded with smart defaults for service business operators.
> Fill in the [BRACKETED] sections after completing your USER.md.
> Your agent will continue adding to this file automatically as it learns your preferences.

---

## Business Context
- **Business:** [BUSINESS NAME]
- **Owner:** [OWNER NAME]
- **Service(s) offered:** [SERVICES]
- **Client types:** [e.g. residential homeowners, small businesses, enterprise]
- **Business model:** [project-based / retainer / hourly]
- **Team size:** [just me / small team]

## Client Roster
| Client | Status | Last Contact | Next Action | Notes |
|--------|--------|-------------|------------|-------|
| [Client 1] | Active | | | |
| [Client 2] | Active | | | |
| [Client 3] | Prospect | | | |

## Operations Defaults
- **Follow-up rule:** Flag any client without contact in 7+ days
- **Appointment buffer:** [e.g. 30 min between jobs]
- **Communication method:** [email / text / Discord]
- **Invoice terms:** [e.g. Net 15 / due on receipt / 50% deposit]
- **Content approval required:** YES — draft all client comms for owner review before sending

## Scheduling Rules
- **Working hours:** [e.g. Mon–Fri 8am–6pm]
- **Days off:** [e.g. Sundays]
- **Booking lead time:** [e.g. 48 hours minimum notice]
- **Over-capacity threshold:** [e.g. flag if more than 5 active projects simultaneously]

## Active Projects
| Project | Client | Deadline | Status | Notes |
|---------|--------|----------|--------|-------|
| | | | | |

## Reminders & Follow-Up Queue
- [Add recurring reminders here as they're set]

## Owner Preferences
- [ADD PREFERENCES HERE — communication style, client quirks, rules]

---

## Pre-Seeded Best Practices (Service Business Operations)

### Client Management
- Every new client gets a welcome message within 24 hours of booking
- Status updates go out proactively — don't make clients ask where things stand
- A client who hasn't heard from you in 10 days is a client looking for a replacement
- Flag problem clients early: scope creep, slow payments, unclear feedback = red flags

### Scheduling
- Always buffer travel or setup time between appointments — back-to-backs create chaos
- Confirm appointments 24 hours in advance with a short message
- Overbooking by even 20% leads to quality drops and reputation damage
- Track capacity weekly: time sold vs time available

### Follow-Up Systems
- Best follow-up timing: 48 hours, 1 week, 1 month after project close
- Ask for referrals at the peak of client satisfaction (job just finished, they're happy)
- Late invoices: friendly reminder at 7 days, firm at 14, firm + call at 21

### Operational Excellence
- Repeatable processes > tribal knowledge — document everything that works
- If something goes wrong twice, it needs a system, not a reminder
- Your hourly rate is only meaningful if your hours are actually billable

---

*Last updated: [auto-updated by agent]*
