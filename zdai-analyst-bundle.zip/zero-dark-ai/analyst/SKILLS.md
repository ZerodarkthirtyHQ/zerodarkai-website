# SKILLS.md — The Analyst Skill Bundle

> These 7 skills ship with every copy of The Analyst. Selected for data-driven operators, researchers, and intelligence-first decision makers.
> Install script handles installation automatically.

---

## Bundled Skills

### 1. `summarize`
**Why it's included:** The analyst's primary tool. Turns market reports, competitor pages, research papers, podcast transcripts, and long-form content into precise, actionable intelligence in seconds.  
**Analyst use case:** "Summarize this 40-page industry report and give me the 5 most important findings" or "What is this competitor's website actually saying about their product positioning?"

---

### 2. `cmc-mcp`
**Why it's included:** Real-time crypto and financial market data for analysts who track digital assets, macro signals, or crypto-adjacent markets as part of their research stack.  
**Analyst use case:** "What's the current BTC dominance and what does that signal for altcoin sentiment?" or "Pull current prices and 24h change for the top 10 DeFi tokens — I'm writing a sector report."

---

### 3. `apple-notes`
**Why it's included:** Research capture and intelligence logging — save findings, source notes, key data points, and decision rationales before they disappear into the ether.  
**Analyst use case:** "Save this market insight to Notes: 'Competitor X raised prices by 15% on Q1 — could signal margin pressure or confidence in demand'" or "Log the key takeaways from today's industry call."

---

### 4. `apple-reminders`
**Why it's included:** Research is time-sensitive. Set reminders for competitor monitoring, report deadlines, earnings calls, and recurring data review cycles.  
**Analyst use case:** "Remind me every Monday to check competitor pricing on the top 5 players" or "Set a reminder for March 15 to pull Q1 market data for the quarterly review."

---

### 5. `content-creator`
**Why it's included:** Write research reports, executive summaries, investor memos, and data narratives — structured, clear, and compelling.  
**Analyst use case:** "Write an executive summary of our competitive landscape analysis — 1 page, board-ready" or "Turn these bullet points into a structured market research report with an intro, findings, and recommendations."

---

### 6. `weather`
**Why it's included:** For analysts covering real-world industries (agriculture, energy, construction, consumer), weather signals are legitimate market data worth monitoring.  
**Analyst use case:** "How is the forecast for the Midwest next 2 weeks relevant to corn futures?" or "Flag any major weather events that could affect supply chain disruption signals I'm tracking."

---

### 7. `seo-keyword-strategist`
**Why it's included:** Keyword data is market research. Search volume, trend curves, and keyword competition reveal consumer intent, market size signals, and emerging niches.  
**Analyst use case:** "What does search trend data tell us about consumer interest in [category] over the last 12 months?" or "Identify emerging keywords in the [niche] space that suggest an underserved market."

---

## Installation

These are installed automatically by `install.sh`. To install manually:

```bash
# Global skills (pre-installed with OpenClaw):
# summarize, cmc-mcp, apple-notes, apple-reminders, weather

# Workspace-local skills (copy from bundle):
cp -r ./skills/content-creator ~/.openclaw/workspace-YOUR-NAME/skills/
cp -r ./skills/seo-keyword-strategist ~/.openclaw/workspace-YOUR-NAME/skills/
```

---

## Skills NOT Included (available as add-ons)

| Skill | Why it's an add-on |
|-------|-------------------|
| `nano-banana-pro` | Image generation — not core to analyst workflow |
| `gog` | Google Workspace — useful add-on for Google Sheets heavy users |
| `github` | Developer-focused |

> Add-on skills available at zerodarkAI.com/packs
