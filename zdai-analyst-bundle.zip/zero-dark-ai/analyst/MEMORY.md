# MEMORY.md — Agent Memory

> This file is your agent's long-term brain. Pre-seeded with smart defaults for data-driven business owners.
> Fill in the [BRACKETED] sections after completing your USER.md.
> Your agent will continue adding to this file automatically as it learns your preferences.

---

## Business Context
- **Business:** [BUSINESS NAME]
- **Owner:** [OWNER NAME]
- **Industry:** [INDUSTRY]
- **Business model:** [MODEL]
- **Key revenue metrics:** [e.g. MRR, ARR, revenue/month]

## Key Metrics Dashboard (Update Weekly)
| Metric | Current | Last Week | Target | Trend |
|--------|---------|-----------|--------|-------|
| [Metric 1] | | | | |
| [Metric 2] | | | | |
| [Metric 3] | | | | |

## Competitor Watchlist
| Competitor | Last Checked | Key Changes | Threat Level |
|------------|-------------|-------------|-------------|
| [Competitor 1] | | | |
| [Competitor 2] | | | |
| [Competitor 3] | | | |

## Markets & Assets Being Tracked
- **Crypto:** [tokens/assets of interest]
- **Markets:** [indices, sectors, or equities]
- **Industry reports:** [recurring reports to monitor]

## Research Backlog
- [Add research requests here as they come in]

## Decision Log
| Date | Decision | Data That Supported It | Outcome |
|------|----------|------------------------|---------|
| | | | |

## Owner Preferences
- **Report format:** [brief summary / detailed analysis]
- **How often to run competitor check:** [weekly / monthly]
- **Key signal to always flag immediately:** [e.g. competitor pricing changes, major market moves]
- **[ADD YOUR OWN RULES HERE]**

---

## Pre-Seeded Best Practices (Data-Driven Business)

### Market Research
- Primary research beats secondary — talk to 10 customers and you'll learn more than reading 100 reports
- Market size estimates are almost always wrong — triangulate from 3 different angles
- Trend ≠ opportunity: a growing market with 50 well-funded competitors is not your opportunity
- The best competitive intelligence comes from customers who left competitors for you — mine those conversations

### Competitive Intelligence
- Monitor competitor job postings — they reveal strategy before any press release does
- Price changes are the most important competitive signal to catch fast
- If a competitor is fundraising, they're about to accelerate — adjust accordingly
- Read their reviews for customer pain points your product could solve

### Financial & Market Data
- Crypto signals to watch: BTC dominance as macro risk indicator, funding rates for sentiment
- Vanity metrics vs real metrics: visitors vs customers, MRR vs total revenue
- CAC payback period is the single most important metric for a growth business
- Rule of 40: revenue growth % + profit margin % should be ≥ 40 for a healthy SaaS

### Reporting
- Lead with the conclusion — no one wants to read 5 pages to find out what matters
- Show the trend line, not just the point-in-time number
- Always label what's "signal" vs "noise" — context is the analyst's most valuable add
- If you can't explain what action the data should drive, the data isn't ready to be reported

---

*Last updated: [auto-updated by agent]*
