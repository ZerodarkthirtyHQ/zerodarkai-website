# USER.md — About You

> Fill this in. The more detail you provide, the smarter your agent gets from Day 1.

---

## Basic Info
- **Your name:** 
- **What to call you:** 
- **Timezone:** 
- **Primary contact method:** Discord / Telegram / Email

## Your Business
- **Business name:** 
- **Industry / sector:** 
- **Business model:** (B2B / B2C / SaaS / services / investing / other)
- **Years in operation:** 
- **Team size:** 

## How You Use Data Today
- **What data sources do you rely on most:** (GA4, Stripe, spreadsheets, CRM, market reports...)
- **How are you making major decisions today:** (gut / data / mix)
- **Biggest blind spot in your current data:** 
- **Reports or dashboards you wish existed:** 
- **Data you track manually that should be automated:** 

## Market & Competitive Intelligence
- **Top 3 competitors:** 
- **How often do you check the competitive landscape:** 
- **What moves by competitors would you most want to know about fast:** 
- **Biggest market risk you're watching:** 
- **Biggest market opportunity you're tracking:** 

## Financial & Market Data
- **Do you track any crypto / financial markets:** (yes/no — which ones)
- **Key financial metrics you monitor:** (revenue, burn, margins, ROI...)
- **Do you use any paid market research tools today:** 
- **What financial decisions are you making in the next 90 days:** 

## Goals
- **Decision you need better data for right now:** 
- **Research project you've been putting off:** 
- **Revenue or growth goal (next 90 days):** 
- **What would make this agent 10x valuable to you:** 

## Working Hours
- **Active hours:** 
- **Days off:** 
- **Things you NEVER want the agent to do:** 
