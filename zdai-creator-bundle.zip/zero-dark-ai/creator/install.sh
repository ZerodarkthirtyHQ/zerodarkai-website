#!/usr/bin/env bash
# ============================================================
# Zero Dark AI — The Creator — Install Script v1.0
# ============================================================
# Installs your AI agent into OpenClaw workspace.
# Run: bash install.sh
# ============================================================

set -euo pipefail

# ── Colors ──────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log()    { echo -e "${CYAN}▶${NC} $*"; }
ok()     { echo -e "${GREEN}✓${NC} $*"; }
warn()   { echo -e "${YELLOW}⚠${NC}  $*"; }
error()  { echo -e "${RED}✗ ERROR:${NC} $*" >&2; }
section(){ echo -e "\n${BOLD}$*${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║   Zero Dark AI — The Creator Installer  ${NC}"
echo -e "${BOLD}║              v1.0  ✨                   ${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── Step 1: Find OpenClaw workspace ─────────────────────────
section "Step 1/5 — Locating OpenClaw workspace..."

WORKSPACE=""
for candidate in \
    "$HOME/.openclaw/workspace" \
    "$HOME/.openclaw/workspace-default" \
    "$HOME/.openclaw/workspaces/default"; do
    if [[ -d "$candidate" ]]; then
        WORKSPACE="$candidate"
        ok "Found workspace at: $WORKSPACE"
        break
    fi
done

if [[ -z "$WORKSPACE" ]] && command -v openclaw &>/dev/null; then
    DETECTED=$(openclaw config get workspace.path 2>/dev/null || true)
    if [[ -n "$DETECTED" && -d "$DETECTED" ]]; then
        WORKSPACE="$DETECTED"
        ok "Found workspace via openclaw config: $WORKSPACE"
    fi
fi

if [[ -z "$WORKSPACE" ]]; then
    warn "Could not auto-detect your OpenClaw workspace."
    echo ""
    read -rp "  Enter your OpenClaw workspace path: " USER_WORKSPACE
    USER_WORKSPACE="${USER_WORKSPACE/#\~//Users/zerodarkthirtyhq}"
    if [[ ! -d "$USER_WORKSPACE" ]]; then
        error "Path does not exist: $USER_WORKSPACE"
        exit 1
    fi
    WORKSPACE="$USER_WORKSPACE"
    ok "Using workspace: $WORKSPACE"
fi

# ── Step 2: Collect info ─────────────────────────────────────
section "Step 2/5 — Tell us about your business..."
echo ""

read -rp "  Business name (e.g. 'Apex Consulting'): " BUSINESS_NAME
if [[ -z "$BUSINESS_NAME" ]]; then error "Business name cannot be empty."; exit 1; fi

read -rp "  Your first name: " OWNER_NAME
if [[ -z "$OWNER_NAME" ]]; then error "Owner name cannot be empty."; exit 1; fi

read -rp "  Your timezone (e.g. 'America/Chicago'): " TIMEZONE
TIMEZONE="${TIMEZONE:-America/Chicago}"

echo ""
ok "Got it. Installing for: $BUSINESS_NAME / $OWNER_NAME / $TIMEZONE"

# ── Step 3: Set up agent directory ───────────────────────────
section "Step 3/5 — Installing agent files..."

DIR_NAME="the-the-creator"
DEST_DIR="${WORKSPACE}/${DIR_NAME}"

if [[ -d "$DEST_DIR" ]]; then
    warn "Directory already exists: $DEST_DIR"
    read -rp "  Overwrite? (y/N): " CONFIRM
    if [[ "$(echo "$CONFIRM" | tr '[:upper:]' '[:lower:]')" != "y" ]]; then
        echo "  Installation cancelled."; exit 0
    fi
fi

mkdir -p "$DEST_DIR"
ok "Created: $DEST_DIR"

SOURCE_AGENT_DIR="${SCRIPT_DIR}/agent"
if [[ ! -d "$SOURCE_AGENT_DIR" ]]; then SOURCE_AGENT_DIR="$SCRIPT_DIR"; fi

install_file() {
    local src="$1"; local dest_name="$2"
    if [[ ! -f "$src" ]]; then warn "Source file not found, skipping: $src"; return; fi
    local dest="${DEST_DIR}/${dest_name}"
    sed \
        -e "s|\[BUSINESS NAME\]|${BUSINESS_NAME}|g" \
        -e "s|\[OWNER NAME\]|${OWNER_NAME}|g" \
        -e "s|\[TIMEZONE\]|${TIMEZONE}|g" \
        "$src" > "$dest"
    ok "Installed: $dest_name"
}

install_file "${SOURCE_AGENT_DIR}/SOUL.md"   "SOUL.md"
install_file "${SOURCE_AGENT_DIR}/USER.md"   "USER.md"
install_file "${SOURCE_AGENT_DIR}/MEMORY.md" "MEMORY.md"
install_file "${SOURCE_AGENT_DIR}/AGENTS.md" "AGENTS.md"

# ── Step 4: Install skills ───────────────────────────────────
section "Step 4/5 — Installing skills..."

SKILLS_DIR="${WORKSPACE}/skills"
mkdir -p "$SKILLS_DIR"

GLOBAL_SKILL_ROOTS=(
    "/opt/homebrew/lib/node_modules/openclaw/skills"
    "/usr/local/lib/node_modules/openclaw/skills"
    "/usr/lib/node_modules/openclaw/skills"
)

check_global_skill() {
    local skill="$1"
    for root in "${GLOBAL_SKILL_ROOTS[@]}"; do
        if [[ -d "${root}/${skill}" ]]; then echo "${root}/${skill}"; return 0; fi
    done
    return 1
}

GLOBAL_SKILLS=(nano-banana-pro summarize cmc-mcp apple-notes weather)
for skill in "${GLOBAL_SKILLS[@]}"; do
    if skill_path=$(check_global_skill "$skill"); then
        ok "Global skill ready: $skill"
    else
        warn "Global skill not found: $skill — may need OpenClaw reinstall"
    fi
done

LOCAL_SKILLS=(content-creator seo-keyword-strategist)
LOCAL_SKILLS_DIR="${SCRIPT_DIR}/skills"
for skill in "${LOCAL_SKILLS[@]}"; do
    src="${LOCAL_SKILLS_DIR}/${skill}"
    dest="${SKILLS_DIR}/${skill}"
    if [[ -d "$src" ]]; then
        [[ -d "$dest" ]] && rm -rf "$dest"
        cp -r "$src" "$dest"
        ok "Installed local skill: $skill → $dest"
    else
        warn "Bundled skill not found: $skill — contact support@zerodarkAI.com"
    fi
done

# ── Step 5: Done ─────────────────────────────────────────────
section "Step 5/5 — Wrapping up..."

echo ""
echo -e "${GREEN}${BOLD}✅ Installation complete!${NC}"
echo ""
echo -e "${BOLD}Your agent (Nova ✨) is installed at:${NC}"
echo "  $DEST_DIR"
echo ""
echo -e "${BOLD}Next steps:${NC}"
echo "  1. Fill in USER.md with your details → $DEST_DIR/USER.md"
echo "  2. Update MEMORY.md with your business context → $DEST_DIR/MEMORY.md"
echo "  3. Start your agent: openclaw gateway start"
echo "  4. Say hello to Nova in Discord ✨"
echo ""
echo -e "Need help? support@zerodarkAI.com | zerodarkAI.com"
echo ""
