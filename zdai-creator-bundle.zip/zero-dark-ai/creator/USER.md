# USER.md — About You

> Fill this in. The more detail you provide, the smarter your agent gets from Day 1.

---

## Basic Info
- **Your name:** 
- **What to call you:** 
- **Timezone:** 
- **Primary contact method:** Discord / Telegram / Email

## Your Creator Profile
- **Primary platform(s):** (TikTok / Instagram / YouTube / X / LinkedIn / other)
- **Niche / content category:** (e.g. fashion, fitness, finance, gaming, lifestyle)
- **Handle(s):** 
- **Current follower count(s):** 
- **How long have you been creating:** 
- **Monetization method(s):** (brand deals, affiliate, merch, digital products, subscriptions)

## Your Content
- **Content format you post most:** (short-form video / long-form / photos / carousels / podcasts)
- **Current posting frequency:** 
- **How long does it take you to create one piece of content today:** 
- **What type of content gets your best engagement:** 
- **What type of content you struggle most to make consistently:** 
- **Videos / posts you're most proud of (why did they work):** 

## Your Audience
- **Who follows you (age range, gender, interests):** 
- **What problems do they come to you to solve:** 
- **What gets the most comments / DMs:** 
- **Biggest complaint from your audience (if any):** 

## Brand & Partnerships
- **Brands you've worked with:** 
- **Types of brand deals you want more of:** 
- **Types of brand deals you'd refuse:** 
- **Your rates (ballpark):** 
- **Affiliate programs you're in:** 

## Goals
- **Follower goal (next 90 days):** 
- **Revenue goal (next 90 days):** 
- **Content output goal (posts per week):** 
- **Biggest bottleneck right now:** 
- **What would make this agent 10x valuable to you:** 

## Working Hours
- **Days/times you create content:** 
- **Days off:** 
- **Things you NEVER want the agent to do:** 
