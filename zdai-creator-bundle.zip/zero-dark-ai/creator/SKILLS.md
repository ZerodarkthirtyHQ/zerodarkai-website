# SKILLS.md — The Creator Skill Bundle

> These 7 skills ship with every copy of The Creator. Selected for content creators, influencers, and digital-first brand builders.
> Install script handles installation automatically.

---

## Bundled Skills

### 1. `content-creator`
**Why it's included:** The core content engine. Writes TikTok scripts, Instagram captions, hooks, carousels, and campaign copy in your exact voice.  
**Creator use case:** "Write 5 TikTok scripts for my 'day in the life' series — casual, unfiltered, strong hook in the first 2 seconds" or "Give me 10 Instagram caption variations for this product photo."

---

### 2. `nano-banana-pro`
**Why it's included:** Professional visual content generation — thumbnails, carousel graphics, brand visuals, product mockups — without a designer or Canva subscription.  
**Creator use case:** "Generate a bold thumbnail for a finance TikTok about passive income — dark background, high contrast text, feels like a hook" or "Create a carousel slide template with my brand colors."

---

### 3. `summarize`
**Why it's included:** Research trends, summarize YouTube videos, Reddit threads, and competitor content — stay ahead without spending 3 hours reading.  
**Creator use case:** "Summarize the top 10 comments on this viral finance TikTok — what are people asking for?" or "What's this 20-page brand deal brief actually asking for, in plain English?"

---

### 4. `seo-keyword-strategist`
**Why it's included:** Search-optimized content gets discovered on YouTube, Pinterest, and Google — creators who ignore SEO leave free traffic on the table.  
**Creator use case:** "What are the top YouTube keywords for a personal finance creator targeting 22–30 year olds?" or "Optimize my YouTube video title and description for search."

---

### 5. `cmc-mcp`
**Why it's included:** Finance, crypto, and business creators need real-time market data to stay credible and relevant when trending market topics hit.  
**Creator use case:** "Bitcoin just spiked — give me 3 TikTok hooks I can use in the next 2 hours while it's trending" or "What's the current market sentiment for a crypto-adjacent post?"

---

### 6. `apple-notes`
**Why it's included:** Capture content ideas, brand deal notes, audience feedback, and creative directions before they evaporate. The creator's idea vault.  
**Creator use case:** "Save this content idea: 'what $1,000/month actually looks like spending-wise in [city]' — format: day-in-the-life TikTok" or "Log that my audience hates when I post after 9pm — it tanks reach."

---

### 7. `weather`
**Why it's included:** Seasonal content, timely trends, and location-aware scripts all get sharper with weather awareness baked in.  
**Creator use case:** "It's going to hit 90° in my city this weekend — give me 3 content angles that tie to the heat wave" or "It's January in NYC — what seasonal content trends should I be filming now?"

---

## Installation

These are installed automatically by `install.sh`. To install manually:

```bash
# Global skills (pre-installed with OpenClaw):
# nano-banana-pro, summarize, cmc-mcp, apple-notes, weather

# Workspace-local skills (copy from bundle):
cp -r ./skills/content-creator ~/.openclaw/workspace-YOUR-NAME/skills/
cp -r ./skills/seo-keyword-strategist ~/.openclaw/workspace-YOUR-NAME/skills/
```

---

## Skills NOT Included (available as add-ons)

| Skill | Why it's an add-on |
|-------|-------------------|
| `apple-reminders` | Useful but not core for creator workflow — most manage their own schedule |
| `gog` | Google Workspace — useful for newsletter/email creators |
| `github` | Developer-focused |

> Add-on skills available at zerodarkAI.com/packs
