#!/usr/bin/env python3
"""
Webhook Inspector — Lightweight Webhook Logger & Proxy
Zero Dark AI | Stanley Hudson, Senior Developer

Runs an HTTP server on port 9999 that:
  1. Captures all incoming webhook payloads to rotating log files
  2. Proxies requests to a configurable real destination
  3. Lets you replay or view captured webhooks

Usage:
    python3 tools/webhook-inspector.py                              # Start server (proxy mode disabled)
    python3 tools/webhook-inspector.py --proxy https://real.api/   # Start server + proxy
    python3 tools/webhook-inspector.py --list                       # List all logged webhooks
    python3 tools/webhook-inspector.py --replay <log-id>           # Replay a captured webhook
    python3 tools/webhook-inspector.py --view <log-id>             # Print full payload
    python3 tools/webhook-inspector.py --clear                      # Delete all logs
"""

import argparse
import json
import os
import sys
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib import request as urllib_request
from urllib.error import URLError

# ── Config ────────────────────────────────────────────────────────────────────

PORT = 9999
LOG_DIR = Path(__file__).parent / "webhook-logs"
MAX_LOGS = 500  # rotate after this many files
LOG_DIR.mkdir(parents=True, exist_ok=True)

PROXY_DESTINATION = None  # set via --proxy at runtime


# ── Logging ───────────────────────────────────────────────────────────────────

def save_webhook(method: str, path: str, headers: dict, body: bytes,
                 source_ip: str) -> str:
    """Save webhook payload to log file. Returns log ID."""
    log_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    log_file = LOG_DIR / f"{log_id}.json"

    # Attempt to parse body as JSON
    try:
        body_parsed = json.loads(body.decode("utf-8", errors="replace"))
        body_display = body_parsed
    except Exception:
        body_display = body.decode("utf-8", errors="replace")

    entry = {
        "id": log_id,
        "timestamp": datetime.now().isoformat(),
        "source_ip": source_ip,
        "method": method,
        "path": path,
        "headers": dict(headers),
        "body_raw": body.decode("utf-8", errors="replace"),
        "body_parsed": body_display,
        "size_bytes": len(body),
    }

    log_file.write_text(json.dumps(entry, indent=2))

    # Enforce rotation: if over MAX_LOGS, delete oldest
    all_logs = sorted(LOG_DIR.glob("*.json"))
    while len(all_logs) > MAX_LOGS:
        all_logs[0].unlink()
        all_logs = all_logs[1:]

    return log_id


def load_log(log_id: str) -> dict | None:
    """Load a specific log by ID."""
    log_file = LOG_DIR / f"{log_id}.json"
    if not log_file.exists():
        return None
    try:
        return json.loads(log_file.read_text())
    except Exception:
        return None


def list_logs() -> list[dict]:
    """Return summary list of all logs, newest first."""
    logs = []
    for f in sorted(LOG_DIR.glob("*.json"), reverse=True):
        try:
            data = json.loads(f.read_text())
            logs.append({
                "id": data.get("id", f.stem),
                "timestamp": data.get("timestamp", ""),
                "method": data.get("method", ""),
                "path": data.get("path", ""),
                "source_ip": data.get("source_ip", ""),
                "size_bytes": data.get("size_bytes", 0),
            })
        except Exception:
            pass
    return logs


# ── Proxy ─────────────────────────────────────────────────────────────────────

def proxy_request(method: str, path: str, headers: dict,
                  body: bytes, destination: str) -> tuple[int, bytes]:
    """Forward request to real destination. Returns (status_code, response_body)."""
    url = destination.rstrip("/") + path
    req = urllib_request.Request(url, data=body if body else None, method=method)

    # Forward select headers
    for key, val in headers.items():
        if key.lower() not in ("host", "content-length", "transfer-encoding"):
            try:
                req.add_header(key, val)
            except Exception:
                pass

    try:
        with urllib_request.urlopen(req, timeout=10) as resp:
            return resp.status, resp.read()
    except URLError as e:
        return 502, str(e).encode()
    except Exception as e:
        return 500, str(e).encode()


# ── HTTP Handler ──────────────────────────────────────────────────────────────

class WebhookHandler(BaseHTTPRequestHandler):
    proxy_dest = None

    def log_message(self, format, *args):
        # Suppress default access log; we do our own
        pass

    def handle_request(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length > 0 else b""
        source_ip = self.client_address[0]

        log_id = save_webhook(
            method=self.command,
            path=self.path,
            headers=dict(self.headers),
            body=body,
            source_ip=source_ip,
        )

        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] 📥 {self.command} {self.path} from {source_ip} "
              f"({len(body)}B) → id={log_id}")

        # Proxy if destination configured
        if WebhookHandler.proxy_dest:
            status, resp_body = proxy_request(
                self.command, self.path, dict(self.headers),
                body, WebhookHandler.proxy_dest
            )
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("X-Webhook-Inspector-ID", log_id)
            self.end_headers()
            self.wfile.write(resp_body)
            print(f"         ↪ Proxied → {WebhookHandler.proxy_dest} [{status}]")
        else:
            # Acknowledge without proxying
            response = json.dumps({"status": "captured", "id": log_id}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(response)))
            self.send_header("X-Webhook-Inspector-ID", log_id)
            self.end_headers()
            self.wfile.write(response)

    def do_POST(self):
        self.handle_request()

    def do_GET(self):
        self.handle_request()

    def do_PUT(self):
        self.handle_request()

    def do_PATCH(self):
        self.handle_request()

    def do_DELETE(self):
        self.handle_request()


# ── CLI Commands ──────────────────────────────────────────────────────────────

def cmd_list():
    logs = list_logs()
    if not logs:
        print("📭 No webhooks captured yet.")
        return

    print(f"\n📋 Captured Webhooks ({len(logs)} total):\n")
    print(f"  {'ID':<32}  {'Timestamp':<20}  {'Method':<8}  {'Path':<30}  {'Source':<16}  {'Size':>8}")
    print(f"  {'-'*32}  {'-'*20}  {'-'*8}  {'-'*30}  {'-'*16}  {'-'*8}")

    for log in logs[:50]:  # show newest 50
        ts = log["timestamp"][:19] if log["timestamp"] else ""
        path = log["path"][:30] if log["path"] else ""
        source = log["source_ip"][:16]
        print(f"  {log['id']:<32}  {ts:<20}  {log['method']:<8}  {path:<30}  {source:<16}  {log['size_bytes']:>7}B")

    if len(logs) > 50:
        print(f"\n  ... and {len(logs) - 50} older entries")
    print()


def cmd_view(log_id: str):
    log = load_log(log_id)
    if not log:
        print(f"❌ Log not found: {log_id}", file=sys.stderr)
        sys.exit(1)

    print(f"\n📦 Webhook: {log_id}")
    print(f"  Timestamp : {log['timestamp']}")
    print(f"  Source IP : {log['source_ip']}")
    print(f"  Method    : {log['method']}")
    print(f"  Path      : {log['path']}")
    print(f"  Size      : {log['size_bytes']} bytes")
    print(f"\n  Headers:")
    for k, v in log.get("headers", {}).items():
        print(f"    {k}: {v}")
    print(f"\n  Body:")
    if isinstance(log.get("body_parsed"), dict):
        print(json.dumps(log["body_parsed"], indent=4))
    else:
        print(log.get("body_raw", "(empty)"))
    print()


def cmd_replay(log_id: str, destination: str):
    log = load_log(log_id)
    if not log:
        print(f"❌ Log not found: {log_id}", file=sys.stderr)
        sys.exit(1)

    if not destination:
        print("❌ Replay requires --proxy <destination> to know where to send it.",
              file=sys.stderr)
        sys.exit(1)

    print(f"🔄 Replaying {log_id} → {destination}")

    body = log.get("body_raw", "").encode("utf-8")
    status, resp = proxy_request(
        log.get("method", "POST"),
        log.get("path", "/"),
        log.get("headers", {}),
        body,
        destination,
    )

    print(f"   Status: {status}")
    print(f"   Response: {resp.decode('utf-8', errors='replace')[:500]}")


def cmd_clear():
    logs = list(LOG_DIR.glob("*.json"))
    for f in logs:
        f.unlink()
    print(f"🗑️  Deleted {len(logs)} log file(s).")


def cmd_serve(proxy_dest: str | None):
    WebhookHandler.proxy_dest = proxy_dest
    server = HTTPServer(("0.0.0.0", PORT), WebhookHandler)

    print(f"\n🕵️  Webhook Inspector running on port {PORT}")
    print(f"   Logs dir   : {LOG_DIR}")
    if proxy_dest:
        print(f"   Proxy dest : {proxy_dest}")
    else:
        print(f"   Proxy dest : (none — capture only)")
    print(f"\n   Send webhooks to: http://localhost:{PORT}/your/path")
    print(f"   View logs: python3 {__file__} --list")
    print(f"\n   Ctrl+C to stop\n")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n⏹  Stopped.")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Webhook Inspector — Capture, proxy, replay webhooks",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--proxy", metavar="URL",
                        help="Forward captured webhooks to this destination URL")
    parser.add_argument("--list", action="store_true",
                        help="List all captured webhooks")
    parser.add_argument("--view", metavar="LOG_ID",
                        help="View full payload of a captured webhook")
    parser.add_argument("--replay", metavar="LOG_ID",
                        help="Replay a captured webhook (requires --proxy)")
    parser.add_argument("--clear", action="store_true",
                        help="Delete all captured webhook logs")
    parser.add_argument("--port", type=int, default=PORT,
                        help=f"Port to listen on (default: {PORT})")

    args = parser.parse_args()

    if args.list:
        cmd_list()
    elif args.view:
        cmd_view(args.view)
    elif args.replay:
        cmd_replay(args.replay, args.proxy)
    elif args.clear:
        cmd_clear()
    else:
        cmd_serve(args.proxy)


if __name__ == "__main__":
    main()
