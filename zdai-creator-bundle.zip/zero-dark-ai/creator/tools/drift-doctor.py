#!/usr/bin/env python3
"""
Drift Doctor — Workspace Drift Analyzer
Zero Dark AI | Stanley Hudson, Senior Developer

Detects drift in critical workspace files, cron jobs, skills, and git state
compared to a saved baseline.

Usage:
    python3 tools/drift-doctor.py --init    # Save current state as baseline
    python3 tools/drift-doctor.py           # Compare current vs baseline, show drift
    python3 tools/drift-doctor.py --json    # JSON output for agent consumption
"""

import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

# ── Config ──────────────────────────────────────────────────────────────────

WORKSPACE = Path(os.environ.get("WORKSPACE", Path(__file__).parent.parent))
BASELINE_PATH = Path(__file__).parent / ".drift-baseline.json"

WATCHED_FILES = [
    "SOUL.md",
    "AGENTS.md",
    "MEMORY.md",
    "HEARTBEAT.md",
    "TOOLS.md",
    "USER.md",
    "REGRESSIONS.md",
]

SKILLS_DIR = WORKSPACE / "skills"

# Section headers to track within files (lines starting with #)
SECTION_PATTERN = "#"


# ── Helpers ──────────────────────────────────────────────────────────────────

def sha256_file(path: Path) -> str:
    """Return SHA256 hash of a file, or empty string if missing."""
    try:
        content = path.read_bytes()
        return hashlib.sha256(content).hexdigest()
    except (FileNotFoundError, PermissionError):
        return ""


def read_file_sections(path: Path) -> list[str]:
    """Extract all heading lines (# ...) from a markdown file."""
    try:
        lines = path.read_text(errors="replace").splitlines()
        return [l.strip() for l in lines if l.strip().startswith(SECTION_PATTERN)]
    except (FileNotFoundError, PermissionError):
        return []


def read_file_content(path: Path) -> str:
    try:
        return path.read_text(errors="replace")
    except (FileNotFoundError, PermissionError):
        return ""


def get_cron_jobs() -> list[str]:
    """Return current user crontab entries (non-comment, non-empty)."""
    try:
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        if result.returncode != 0:
            return []
        lines = [l.strip() for l in result.stdout.splitlines()
                 if l.strip() and not l.strip().startswith("#")]
        return sorted(lines)
    except Exception:
        return []


def get_skills() -> list[str]:
    """Return sorted list of installed skill directories."""
    if not SKILLS_DIR.exists():
        return []
    return sorted([d.name for d in SKILLS_DIR.iterdir() if d.is_dir()])


def get_git_commit_hash() -> str:
    """Return current HEAD commit hash."""
    try:
        result = subprocess.run(
            ["git", "-C", str(WORKSPACE), "rev-parse", "HEAD"],
            capture_output=True, text=True
        )
        return result.stdout.strip() if result.returncode == 0 else ""
    except Exception:
        return ""


def get_git_log_since(since_hash: str) -> list[str]:
    """Return commit messages since baseline hash."""
    if not since_hash:
        return []
    try:
        result = subprocess.run(
            ["git", "-C", str(WORKSPACE), "log",
             f"{since_hash}..HEAD", "--oneline"],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            return []
        return [l.strip() for l in result.stdout.splitlines() if l.strip()]
    except Exception:
        return []


# ── Snapshot ─────────────────────────────────────────────────────────────────

def take_snapshot() -> dict:
    """Capture current workspace state."""
    files = {}
    for fname in WATCHED_FILES:
        fpath = WORKSPACE / fname
        files[fname] = {
            "hash": sha256_file(fpath),
            "exists": fpath.exists(),
            "sections": read_file_sections(fpath),
            "size": fpath.stat().st_size if fpath.exists() else 0,
        }

    return {
        "timestamp": datetime.now().isoformat(),
        "git_commit": get_git_commit_hash(),
        "files": files,
        "cron_jobs": get_cron_jobs(),
        "skills": get_skills(),
    }


def save_baseline(snapshot: dict):
    BASELINE_PATH.parent.mkdir(parents=True, exist_ok=True)
    BASELINE_PATH.write_text(json.dumps(snapshot, indent=2))
    print(f"✅ Baseline saved → {BASELINE_PATH}")
    print(f"   Timestamp : {snapshot['timestamp']}")
    print(f"   Git commit: {snapshot['git_commit'][:12] if snapshot['git_commit'] else 'n/a'}")
    print(f"   Files     : {len(snapshot['files'])}")
    print(f"   Skills    : {len(snapshot['skills'])}")
    print(f"   Cron jobs : {len(snapshot['cron_jobs'])}")


def load_baseline() -> dict | None:
    if not BASELINE_PATH.exists():
        return None
    try:
        return json.loads(BASELINE_PATH.read_text())
    except Exception as e:
        print(f"❌ Failed to load baseline: {e}", file=sys.stderr)
        return None


# ── Diff Engine ───────────────────────────────────────────────────────────────

def severity(score: int) -> str:
    if score >= 3:
        return "HIGH"
    elif score >= 1:
        return "MEDIUM"
    return "LOW"


def diff_files(baseline: dict, current: dict) -> list[dict]:
    findings = []
    base_files = baseline.get("files", {})
    curr_files = current.get("files", {})

    all_keys = set(base_files) | set(curr_files)

    for fname in sorted(all_keys):
        b = base_files.get(fname, {})
        c = curr_files.get(fname, {})

        # File presence changes
        if b.get("exists", False) and not c.get("exists", False):
            findings.append({
                "type": "file_deleted",
                "file": fname,
                "severity": "HIGH",
                "detail": f"{fname} was present in baseline but is now MISSING",
            })
            continue

        if not b.get("exists", False) and c.get("exists", False):
            findings.append({
                "type": "file_added",
                "file": fname,
                "severity": "LOW",
                "detail": f"{fname} is new (not in baseline)",
            })
            continue

        if not b.get("exists") and not c.get("exists"):
            continue

        # Hash change → content changed
        if b.get("hash") != c.get("hash"):
            b_sections = set(b.get("sections", []))
            c_sections = set(c.get("sections", []))
            added = c_sections - b_sections
            removed = b_sections - c_sections

            score = 0
            details = []

            if removed:
                score += len(removed) * 2
                details.append(f"Sections removed: {', '.join(sorted(removed))}")
            if added:
                score += len(added)
                details.append(f"Sections added: {', '.join(sorted(added))}")

            size_change = c.get("size", 0) - b.get("size", 0)
            if abs(size_change) > 500:
                score += 1
                details.append(f"Size changed by {size_change:+d} bytes")

            if not details:
                details.append("Content changed (no section changes detected)")
                score = 1

            findings.append({
                "type": "file_modified",
                "file": fname,
                "severity": severity(score),
                "detail": " | ".join(details),
                "sections_added": sorted(added),
                "sections_removed": sorted(removed),
                "size_change": size_change,
            })

    return findings


def diff_cron(baseline: dict, current: dict) -> list[dict]:
    findings = []
    b_cron = set(baseline.get("cron_jobs", []))
    c_cron = set(current.get("cron_jobs", []))

    for job in sorted(c_cron - b_cron):
        findings.append({
            "type": "cron_added",
            "severity": "MEDIUM",
            "detail": f"New cron job: {job}",
        })

    for job in sorted(b_cron - c_cron):
        findings.append({
            "type": "cron_removed",
            "severity": "MEDIUM",
            "detail": f"Removed cron job: {job}",
        })

    return findings


def diff_skills(baseline: dict, current: dict) -> list[dict]:
    findings = []
    b_skills = set(baseline.get("skills", []))
    c_skills = set(current.get("skills", []))

    for skill in sorted(c_skills - b_skills):
        findings.append({
            "type": "skill_added",
            "severity": "LOW",
            "detail": f"New skill installed: {skill}",
        })

    for skill in sorted(b_skills - c_skills):
        findings.append({
            "type": "skill_removed",
            "severity": "MEDIUM",
            "detail": f"Skill removed: {skill}",
        })

    return findings


def diff_git(baseline: dict) -> list[dict]:
    findings = []
    base_commit = baseline.get("git_commit", "")
    commits = get_git_log_since(base_commit)

    if commits:
        findings.append({
            "type": "git_commits",
            "severity": "LOW",
            "detail": f"{len(commits)} commit(s) since baseline",
            "commits": commits[:20],  # cap at 20
        })

    return findings


# ── Report ────────────────────────────────────────────────────────────────────

SEVERITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
SEVERITY_EMOJI = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}


def print_report(findings: list[dict], baseline: dict, current: dict):
    high = [f for f in findings if f["severity"] == "HIGH"]
    medium = [f for f in findings if f["severity"] == "MEDIUM"]
    low = [f for f in findings if f["severity"] == "LOW"]

    print()
    print("╔══════════════════════════════════════════════════════════╗")
    print("║              🩺 DRIFT DOCTOR — WORKSPACE REPORT           ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print(f"  Baseline : {baseline.get('timestamp', 'unknown')[:19]}")
    print(f"  Current  : {current['timestamp'][:19]}")
    base_commit = baseline.get('git_commit', '')
    curr_commit = current.get('git_commit', '')
    print(f"  Git      : {base_commit[:12] or 'n/a'} → {curr_commit[:12] or 'n/a'}")
    print()

    if not findings:
        print("  ✅ No drift detected. Workspace matches baseline.")
        print()
        return

    print(f"  Found {len(findings)} drift item(s):  "
          f"🔴 {len(high)} HIGH  🟡 {len(medium)} MEDIUM  🟢 {len(low)} LOW")
    print()

    # Sort by severity
    sorted_findings = sorted(findings, key=lambda f: SEVERITY_ORDER[f["severity"]])

    for f in sorted_findings:
        emoji = SEVERITY_EMOJI[f["severity"]]
        print(f"  {emoji} [{f['severity']}] {f['type'].upper()}")
        print(f"     {f['detail']}")

        if f.get("sections_added"):
            for s in f["sections_added"]:
                print(f"       + {s}")
        if f.get("sections_removed"):
            for s in f["sections_removed"]:
                print(f"       - {s}")
        if f.get("commits"):
            for c in f["commits"][:5]:
                print(f"       · {c}")
            if len(f["commits"]) > 5:
                print(f"       · ... and {len(f['commits']) - 5} more")
        print()

    # Summary verdict
    if high:
        print("  ⚠️  VERDICT: HIGH severity drift detected. Review immediately.")
    elif medium:
        print("  ⚠️  VERDICT: Moderate drift. Review when possible.")
    else:
        print("  ✅ VERDICT: Minor drift only. No immediate action needed.")
    print()


# ── CLI Entry Point ───────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Drift Doctor — Workspace Drift Analyzer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--init", action="store_true",
                        help="Save current state as baseline")
    parser.add_argument("--json", action="store_true",
                        help="Output as JSON (for agent consumption)")
    args = parser.parse_args()

    if args.init:
        snapshot = take_snapshot()
        save_baseline(snapshot)
        return

    baseline = load_baseline()
    if baseline is None:
        print("❌ No baseline found. Run with --init first:", file=sys.stderr)
        print("   python3 tools/drift-doctor.py --init", file=sys.stderr)
        sys.exit(1)

    current = take_snapshot()

    findings = []
    findings.extend(diff_files(baseline, current))
    findings.extend(diff_cron(baseline, current))
    findings.extend(diff_skills(baseline, current))
    findings.extend(diff_git(baseline))

    if args.json:
        output = {
            "baseline_timestamp": baseline.get("timestamp"),
            "current_timestamp": current["timestamp"],
            "baseline_commit": baseline.get("git_commit", ""),
            "current_commit": current.get("git_commit", ""),
            "total_findings": len(findings),
            "high": len([f for f in findings if f["severity"] == "HIGH"]),
            "medium": len([f for f in findings if f["severity"] == "MEDIUM"]),
            "low": len([f for f in findings if f["severity"] == "LOW"]),
            "findings": sorted(findings, key=lambda f: SEVERITY_ORDER[f["severity"]]),
        }
        print(json.dumps(output, indent=2))
        return

    print_report(findings, baseline, current)


if __name__ == "__main__":
    main()
