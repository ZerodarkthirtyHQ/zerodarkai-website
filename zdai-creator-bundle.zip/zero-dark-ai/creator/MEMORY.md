# MEMORY.md — Agent Memory

> This file is your agent's long-term brain. Pre-seeded with smart defaults for content creators and influencers.
> Fill in the [BRACKETED] sections after completing your USER.md.
> Your agent will continue adding to this file automatically as it learns your preferences.

---

## Creator Profile
- **Handle(s):** [HANDLES]
- **Name:** [OWNER NAME]
- **Primary platform:** [PLATFORM]
- **Niche:** [NICHE]
- **Audience size:** [FOLLOWER COUNT]
- **Monetization:** [HOW YOU MAKE MONEY]

## Brand Voice
- **Tone:** [e.g. Funny, relatable, unfiltered — talks to the audience like a best friend]
- **Never say:** [e.g. "I", corporate words, anything that sounds AI-generated]
- **Always:** [e.g. Short sentences, casual language, hook in the first word]
- **Sample caption they love:** [paste one]
- **Sample hook that crushed:** [paste one]

## Content Defaults
- **Script structure:** Hook → Pattern Interrupt → Value → CTA
- **Default hook formats that work:** [fill in from experience]
- **CTA rotation:** [e.g. "comment X", "link in bio", "follow for pt 2"]
- **Posting schedule:** [platform: frequency]
- **Best posting times:** [platform: time]
- **Content approval required:** YES — all scripts/captions need 👍 before use

## Trending Signals to Watch
- [HASHTAGS / SOUNDS / FORMATS that are working right now — update regularly]

## Brand Deal Tracker
| Brand | Status | Rate | Content Deliverables | Deadline |
|-------|--------|------|---------------------|----------|
| | | | | |

## Affiliate Programs
| Program | Link | Commission | Best performing content |
|---------|------|-----------|------------------------|
| | | | |

## Content Ideas Backlog
- [Add raw ideas here — the agent will help develop them]

---

## Pre-Seeded Best Practices (Content Creation & Growth)

### Hooks That Stop the Scroll
- Best hook formats: "POV:", "Tell me why...", "Nobody talks about this but...", numbers ("5 things...")
- Hook = pattern interrupt + curiosity gap — make them NEED to know what comes next
- First 2 seconds determine if the algorithm promotes it — front-load the most interesting moment
- Hook testing: write 10 hooks per idea, use the most uncomfortable one

### Short-Form Video (TikTok / Reels)
- UGC-style (casual, phone-shot) outperforms polished 80% of the time in most niches
- Perfect video length: as short as possible while still delivering the value
- Trending sounds boost reach by 2–3x — use them even if tangentially related
- Reply to comments with videos — comment replies get 2x reach

### Instagram Growth
- Carousels: swipe-bait slide 1, then deliver value on slides 2–7, CTA on last slide
- Stories convert followers to buyers better than feed posts
- Reels get reach, Stories get sales
- Post at the same time daily — the algorithm rewards consistency

### Trend Research
- TikTok "For You" page in incognito = unbiased trend feed
- Check Exploding Topics weekly for niches trending 3–6 months out
- If 3+ creators in your niche hit the same format in 48 hours — jump on it today
- Avoid: hopping on trends that peak on a Tuesday and you post Sunday

### Monetization
- Brand deals: charge 3x your lowest offer — they'll negotiate down, never up
- Affiliate > brand deals for long-term passive income
- Digital products: once-built, infinite scale — hardest part is the first one
- Your most engaged 1,000 fans are worth more than 100,000 passive followers

---

*Last updated: [auto-updated by agent]*
