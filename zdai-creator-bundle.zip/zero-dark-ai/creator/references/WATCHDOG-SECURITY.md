# Watchdog Security Agent — Reference
*Source: souls.zip (free agent, 320 downloads) — logged 2026-03-06*
*Download: https://souls.zip → Watchdog (free)*

## What It Is
A 4-skill security monitoring agent for OpenClaw deployments. Detection-only — it never modifies anything, only reports. Designed for daily/weekly automated scans.

## The 4 Skills

### 1. Security Audit
Full infrastructure assessment with severity ratings.
- Checks open ports, exposed services, misconfigured daemons
- Rates findings: CRITICAL / HIGH / MEDIUM / LOW
- Outputs structured report, not a wall of text
- Never auto-remediates — always flags for human decision

### 2. Permission Sweep
File and directory permission analysis across the workspace.
- Finds world-readable secrets, over-permissioned scripts
- Checks `.env` files are `chmod 600` (not 644 or 755)
- Checks API key files and credential directories
- Reports exact paths + current vs recommended permissions

### 3. Secret Scanner
Credentials exposed across all workspaces, repos, and config files.
- Scans for: API keys, tokens, passwords, private keys, connection strings
- Checks git history (not just working tree) — catches removed-but-committed secrets
- Checks shell RC files (`.zshrc`, `.bashrc`, `.bash_profile`)
- Output: file path + line number + severity, no actual secret values printed

### 4. Compound Engineer
Security posture trends over time — not just point-in-time snapshots.
- Compares current scan vs previous scan
- Tracks: new findings, resolved findings, repeat offenders
- Generates trend data: "posture improved / degraded / stable"
- Surfaces systemic patterns (e.g., new skills consistently misconfigure permissions)

## How We Apply This

### Currently Implemented (Creed)
Creed's nightly security audit cron covers similar ground but is less structured. Creed runs:
- `chmod` checks on `.env` files
- General security posture review
- Reports to #creed channel

### Gap: What Watchdog Does Better
- Structured severity ratings (Creed's reports are narrative, not scored)
- Compound/trend tracking over time (Creed is snapshot-only)
- Git history secret scanning (Creed doesn't scan git history)
- Explicit permission sweep (Creed's permission checks are ad hoc)

### Integration Path
Option A: Download Watchdog ZIP → feed to Creed as skill upgrade
Option B: Rebuild Creed's audit skill using Watchdog's 4-skill architecture as the template
Option C: Run both (Watchdog for infrastructure, Creed for agent-level security)

**Recommended:** Option B — Creed rebuilds using this architecture. Gives us the structure without a foreign SOUL.md we didn't write.

## Quick Reference: Bash Checks (No LLM Needed)

Run these manually or via Creed's cron — zero token cost:

```bash
# Check .env permissions
find ~/.openclaw -name ".env" -exec ls -la {} \;
find ~/workspace -name ".env" -exec ls -la {} \;

# Scan for hardcoded secrets in workspace (non-git)
grep -r "sk-" ~/.openclaw/workspace-prison-mike --include="*.js" --include="*.py" --include="*.ts" -l
grep -r "api_key" ~/.openclaw/workspace-prison-mike --include="*.js" --include="*.py" -l

# Check git history for accidentally committed secrets
git -C ~/.openclaw/workspace-prison-mike log --all --full-history -p -- "*.env" | grep -E "(api_key|token|secret|password)" | head -20

# Check what's listening on open ports
lsof -i -P -n | grep LISTEN

# Verify no world-readable credential files
find ~/.openclaw -name "*.json" -perm -o=r | grep -E "(token|key|secret|credential)"
```

## The 10/3 Rule (Skill Install Safety)
Before installing ANY skill from souls.zip or clawhub:
- 100+ downloads AND 3+ months old = safer to trust
- Under either threshold = read source code before installing
- Any skill requesting daily cron + full workspace access = mandatory source audit

## Source
- souls.zip Watchdog page: https://souls.zip (free, no account required)
- SkillGuard protocol: `skills/prompt-guard/` in workspace
- Creed's channel: `#🕵️-creed`
