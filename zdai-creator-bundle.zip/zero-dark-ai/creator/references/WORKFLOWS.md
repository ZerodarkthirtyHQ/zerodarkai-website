# 20 Proven OpenClaw Workflows
*Source: souls.zip / @moritzkremb (50-day daily use review) — extracted 2026-03-06*
*Original: https://souls.zip → "20 Proven OpenClaw Workflows" (free, claimable)*

These are battle-tested production workflows across 6 categories. Copy-paste prompts that work.

---

## Category 1: Daily Operations

### Workflow 1 — Morning Standup Briefing
Trigger: 7:00 AM daily cron
```
Run morning briefing:
1. Check today's calendar and any pending tasks from yesterday
2. Pull crypto market snapshot (BTC, ETH, XRP prices + Fear & Greed)
3. Surface top 3 priorities for today based on active projects
4. Flag any overnight alerts, errors, or sub-agent failures
5. Post to #morning-brief channel. Keep it under 300 words. Be direct.
```
**Our implementation:** `morning-briefing` cron ✅ ACTIVE (7 AM daily)

### Workflow 2 — End-of-Day Recap
Trigger: 10:05 PM daily cron
```
Run nightly recap:
1. Read git log for today's commits
2. Summarize what actually got done (not what was planned)
3. List anything still open / blocked / needs Ben's input
4. Set 3 priorities for tomorrow
5. Post to #nightly-recap. No fluff.
```
**Our implementation:** `discord-nightly-recap` cron ✅ ACTIVE (10:05 PM daily)

### Workflow 3 — Discord Routing by Model (Cost Optimization)
Pattern: Route different request types to different models
```
Classification prompt (Haiku): "Is this request: [A] simple lookup/factual, [B] complex reasoning/planning, [C] code generation?"
Route: A → Haiku | B → Sonnet | C → Sonnet/Opus
```
**Our implementation:** Model selection logic in AGENTS.md ✅ ACTIVE

---

## Category 2: Research & Intelligence

### Workflow 4 — Deep Multi-Agent Research
Trigger: Manual or cron
```
Spawn coordinated research:
Agent 1 (Toby): Primary source research + synthesis
Agent 2 (Dwight): Market/competitive angle
Agent 3 (Oscar): Data verification + fact-checking

Final output: Single consolidated brief under 500 words.
No overlapping assignments. Each agent reads others' output before finalizing.
```
**Use case:** Pre-build research, competitive analysis, investment thesis validation

### Workflow 5 — YouTube Analytics & Channel Growth
Trigger: Weekly
```
Pull YouTube channel data:
1. Get last 7 days of videos for [channel]
2. Calculate: avg views, CTR, retention, subscriber delta
3. Identify top performer + bottom performer this week
4. Recommend: 1 format to double down on, 1 to cut
5. Extract top 3 hooks that outperformed (for content reuse)
```
**Use case:** Content Rewards channel optimization, FightClaw content tracking

### Workflow 6 — Competitor Review Mining
Trigger: Manual (pre-build)
```
Mine competitor App Store reviews:
1. Fetch 1-3 star reviews for [app_id] from iTunes RSS API
2. Cluster by complaint type: UX, missing features, reliability, pricing
3. Rank clusters by frequency × frustration level
4. Output: Top 10 features users beg for that the app doesn't have
5. Format as feature spec for our build
```
**Our implementation:** Applied to Vanish (competitor: DeleteMe, Incogni, Aura)

---

## Category 3: Content & Publishing

### Workflow 7 — Content Batch Generation
Trigger: Daily or weekly
```
Generate [N] content pieces for [platform]:
Format: [short-form video scripts / tweet threads / LinkedIn posts]
Tone: [Ben's voice profile — see CONTENT-STYLE.md]
Topics: Pull from [content calendar / trending topics in niche]
Output: Numbered list, ready to copy-paste. No AI preamble.
```
**Our implementation:** Pam's content engine + `content-engine/` scripts

### Workflow 8 — Tweet Draft → Review → Post Pipeline
```
Step 1: Draft tweet for [topic/event]
Step 2: Post draft to #fightclawhq_x for Ben review
Step 3: Ben reacts 👍 → `bird` CLI posts to X
Step 4: Log post to daily note
```
**Our implementation:** FightClaw + Zero Dark AI X pipeline ✅ ACTIVE

### Workflow 9 — Bookmark Automation (Knowledge Capture)
Trigger: When Ben drops link in #link-drops
```
On new link in #link-drops:
1. Fetch URL content (summarize to 100 words)
2. Classify: Tool / Article / Reference / Project
3. Add to appropriate section of telegram-links/links-curated.md
4. Update #skills-secret-sauce nightly delta
```
**Our implementation:** `skills-library-nightly-delta` cron ✅ ACTIVE (10 PM daily)

---

## Category 4: Monitoring & Alerts

### Workflow 10 — Server/Gateway Health Monitor (2-Layer Pattern)
Layer 1 (bash, zero tokens):
```bash
#!/bin/bash
openclaw status > /dev/null 2>&1
if [ $? -ne 0 ]; then
  openclaw cron run <alert-job-id>
fi
```
Layer 2 (LLM, only on failure):
```
Gateway down. Check: process status, last restart time, log tail.
Diagnose and alert Ben with: what's down, likely cause, recommended fix.
```
**Our implementation:** Elvis Protocol (gateway-precheck.sh) + LaunchAgent ✅ ACTIVE

### Workflow 11 — Sub-Agent Timeout Handler
```
On sub-agent timeout:
1. Check git log for partial progress
2. If progress found: re-spawn with continuation prompt (1.5x timeout)
3. If no progress: escalate to Ben
4. Log retry attempt to daily note
Max retries: 2. Never retry wallet/auth/destructive tasks.
```
**Our implementation:** HEARTBEAT.md Auto-Retry Protocol ✅ ACTIVE

### Workflow 12 — Cron Health Watchdog
Trigger: Every 6 hours
```
Check cron health:
1. openclaw cron list --json
2. Flag any jobs with consecutiveErrors > 0
3. Auto-retry once if error is transient
4. Escalate to Ben if 3+ consecutive errors
5. Log findings to #cron-logs
```
**Our implementation:** `cron-watchdog-and-audit` cron ✅ ACTIVE

---

## Category 5: Memory & Context Management

### Workflow 13 — Nightly Memory Consolidation
Trigger: 2:30 AM daily
```
Memory consolidation:
1. Read today's daily note
2. Extract: decisions, preferences, corrections, new facts
3. Classify: Bootstrap tier (MEMORY.md) vs Archive tier (MEMORY-ARCHIVE.md)
4. Append new entries with date stamps
5. Re-index QMD
6. Clean up daily note (remove resolved tasks, completed items)
```
**Our implementation:** `memory-consolidation` cron ✅ ACTIVE (2:30 AM)

### Workflow 14 — Pre-Compaction Checkpoint
Trigger: When context window reaches ~60%
```
Write checkpoint to memory/session-state.md:
- Last 3-5 exchanges (paraphrased, not summarized)
- Pending proposals/questions verbatim
- Active task + current status
- Decisions in flight
- Emotional/conversational tone
Test: "Could I wake up with only this and continue seamlessly?"
```
**Our implementation:** AGENTS.md compaction protocol ✅ DOCUMENTED

### Workflow 15 — QMD Semantic Search (vs. Raw File Read)
Instead of reading 5 files to answer a question:
```bash
export PATH="$HOME/.bun/bin:$PATH"
qmd search "your query" --limit 5
```
Returns ranked relevant snippets from entire workspace in <1 second.
**Use when:** Any question that might be in a reference doc or past decision.

---

## Category 6: Agent Improvement

### Workflow 16 — Weekly Agent Performance Review (Monica Protocol)
Trigger: Sunday 9 AM
```
Review each agent (Dwight, Pam, Stanley, Creed):
Grade A/B/C on: accuracy, speed, output quality, consistency
A = no change | B = flag for discussion | C = rewrite prompt + add eval criteria
Update calibration scores in MEMORY.md
Post report to #prison-mike
Ben responds → Prison Mike implements changes
```
**Our implementation:** `weekly-agent-review` cron ✅ ACTIVE (Sun 9 AM)
Reference: `references/WEEKLY-AGENT-REVIEW.md`

### Workflow 17 — Email Triage (Draft-Only Mode)
```
Process inbox:
1. Categorize: Urgent / FYI / Action Required / Junk
2. For Action Required: draft reply (NEVER send without explicit approval)
3. Present drafts to Ben: "Here's my draft — want me to send?"
4. Ben approves → send | Ben edits → update → send
Safety gate: Never auto-send. Draft-only always.
```
**Not yet implemented.** Trigger: when Ben connects email via gog skill.

### Workflow 18 — Boardroom Decision Gate
Trigger: Any decision above $500 or irreversible
```bash
boardroom analyze "Should we [decision]?"
```
Returns: 7-advisor analysis, required dissent, risk classification, recommendation
**Our implementation:** `boardroom-mcp/` ✅ INSTALLED

### Workflow 19 — Sub-Agent Context Budget Enforcement
Before spawning any sub-agent:
```
If task will read 3+ files OR produce output Ben doesn't need verbatim → delegate.
Spawn with: "Summarize findings in <500 words. Do NOT return raw file content."
Model: Haiku for reads, Sonnet for analysis, Opus only if Ben specified.
```
**Our implementation:** Context Management rules in AGENTS.md ✅ DOCUMENTED

### Workflow 20 — Git Commit Protocol (Non-Negotiable)
After ANY file creation or significant edit:
```bash
cd /Users/zerodarkthirtyhq/.openclaw/workspace-prison-mike
git add -A
git commit -m "AgentName: [brief description]"
```
Rule: If it's not committed, it doesn't exist tomorrow.
**Our implementation:** Hardcoded into all sub-agent task prompts ✅

---

## Quick Reference: When to Use Which Workflow

| Situation | Workflow |
|-----------|----------|
| Morning kickoff | #1 — Standup Briefing |
| Research needed | #4 — Multi-Agent Research |
| New iOS/web competitor | #6 — Review Mining |
| Content needed | #7 — Batch Generation |
| Tweet ready | #8 — Draft → Review → Post |
| Link dropped in Discord | #9 — Bookmark Automation |
| Gateway down | #10 — 2-Layer Health Monitor |
| Sub-agent timed out | #11 — Timeout Handler |
| Big decision | #18 — Boardroom Gate |
| File created | #20 — Git Commit (always) |

---

*Full souls.zip research: `references/SOULS-ZIP-RESEARCH.md`*
*Last updated: 2026-03-06*
