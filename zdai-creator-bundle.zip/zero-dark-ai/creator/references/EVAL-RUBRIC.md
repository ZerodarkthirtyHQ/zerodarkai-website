# Agent Evaluation Rubric — Custom Evals > Benchmarks
*Source: souls.zip research + Monica Protocol — integrated 2026-03-06*
*Principle: Evals on YOUR tasks beat any benchmark. A rubric only matters if it reflects what you actually need.*

---

## The Core Principle

Generic benchmarks (MMLU, HumanEval, MATH) measure what the model does on someone else's tasks. What matters is how well the agent does on YOUR specific tasks, at YOUR quality bar.

**Build custom evals. Run them weekly. Adjust prompts based on results.**

---

## Prison Mike's 5-Dimension Agent Rubric

Use this for the Monica Protocol weekly grading session.

### Dimension 1: Task Completion Rate (TCR)
*Did the agent finish what it started?*

| Score | Definition |
|-------|-----------|
| A (90%+) | Completes assigned tasks without retry 90%+ of the time |
| B (70-89%) | Completes most tasks; occasional retry needed |
| C (<70%) | Frequent timeouts, incomplete outputs, or requires significant intervention |

**How to measure:** Count sub-agent tasks that completed without retry vs. those that needed intervention. Check heartbeat logs for auto-retries.

---

### Dimension 2: Output Quality (OQ)
*Is the output actually usable without significant editing?*

| Score | Definition |
|-------|-----------|
| A | Output is used as-is or with minor edits (<20% rewrite) |
| B | Output needs significant editing but provides a solid foundation |
| C | Output is incorrect, hallucinated, or requires complete redo |

**How to measure:** Ben's reaction on delivery — did he use it, edit it, or reject it? Track in daily notes.

---

### Dimension 3: Signal-to-Noise Ratio (SNR)
*Is the agent concise, or does it pad everything?*

| Score | Definition |
|-------|-----------|
| A | Reports are dense and actionable. No filler. Gets to the point immediately. |
| B | Some padding and preamble, but core content is solid |
| C | Verbose outputs, excessive caveats, repeats instructions back, needs trimming |

**How to measure:** Count Ben complaints about "too long" or "get to the point" per week.

---

### Dimension 4: Autonomy Level (AL)
*How much hand-holding does the agent require?*

| Score | Definition |
|-------|-----------|
| A | Operates independently on complex multi-step tasks with no check-ins |
| B | Completes tasks but needs clarifying questions or occasional steering |
| C | Requires significant guidance, frequent check-ins, or frequent escalations |

**How to measure:** Count messages Ben had to send to correct course during a task. Zero = A, 1-2 = B, 3+ = C.

---

### Dimension 5: Rule Adherence (RA)
*Does the agent follow SOUL.md, AGENTS.md, and established protocols?*

| Score | Definition |
|-------|-----------|
| A | Never violates hard rules. Follows protocols automatically. Self-corrects. |
| B | Occasional minor rule violations (style, not safety). Fixed on reminder. |
| C | Ignores established protocols, repeats errors from REGRESSIONS.md, or violates hard rules |

**How to measure:** Check REGRESSIONS.md for new entries caused by the agent this week.

---

## Weekly Grading Sheet

```markdown
## Agent Review — [DATE]

### 🥬 Dwight Schrute (Market Intel)
- TCR: [ A / B / C ]
- OQ:  [ A / B / C ]
- SNR: [ A / B / C ]
- AL:  [ A / B / C ]
- RA:  [ A / B / C ]

Overall Grade: [ A / B / C ]
Notes: 
Calibration Score Delta: [+10 / 0 / -15]
Action: [none / flag / rewrite prompt section: ___]

---

### 🧮 Stanley Hudson (Dev)
[same fields]

### 🎨 Pam Beesly (Creative)
[same fields]

### 🕵️ Creed Bratton (Security)
[same fields]
```

---

## Grading Scale (Monica Protocol Integration)

| Grade | Score Impact | Action Required |
|-------|-------------|-----------------|
| A (all dimensions 90%+) | +10 pts to calibration score | No prompt changes |
| B (mixed) | 0 pts | Flag weak dimensions, monitor next week |
| C (any dimension) | -15 pts | Rewrite prompt for failing dimension, add explicit eval criteria |

**Weekly decay:** -5 pts automatically (forces ongoing performance, prevents "passed once, never checked again")

---

## Task-Specific Evals

Beyond weekly grading, run evals on specific task types the agent handles.

### Dwight: Market Intelligence Eval
Run weekly on 5 randomly sampled Dwight reports:
1. **Accuracy:** Are facts verifiable? (0 = hallucinated, 1 = unverified, 2 = cited)
2. **Relevance:** Does the report surface actionable intelligence vs. noise? (1-5)
3. **Timeliness:** Did the report cover events from the past 24h, or was it stale?

Target: avg score > 4/5. Below 3/5 = prompt revision.

### Stanley: Code Quality Eval
On each completed build:
1. **Does it run?** (yes/no — binary)
2. **Did it need retry?** (yes/no)
3. **Test coverage:** Did Stanley write tests? (yes/partial/no)
4. **Git commit?** (yes/no — mandatory)

Target: 100% on "does it run?" and "git commit?". Below 90% = REGRESSIONS.md entry.

### Pam: Creative Quality Eval
On each content batch:
1. **Ben approval rate:** % of drafts used without rewrite
2. **Voice adherence:** Does it match CONTENT-STYLE.md? (Ben rates 1-5)
3. **Platform fit:** Correct format, length, hashtags for platform?

Target: 70%+ approval rate. Below 50% = content style prompt overhaul.

### Creed: Security Eval
Monthly:
1. **Coverage:** % of workspace scanned (vs. prior month)
2. **Finding quality:** Were findings actionable, or generic warnings?
3. **False positive rate:** Did Creed flag things that weren't actually risks?

Target: Zero false critical findings. Any missed HIGH-severity finding = -15 pts, immediate review.

---

## The Cardinal Rule

> "Evals on your tasks beat any benchmark. A model that scores 90% on MMLU but fails your specific use case is useless. A model that scores 70% on MMLU but nails your workflow is gold."

Run your evals. Trust your data. Ignore leaderboards.

---

## Eval Log Location
Weekly grades → MEMORY.md (Calibration Scores table)
Task-specific evals → `memory/YYYY-MM-DD.md` (daily notes)
Prompt rewrites triggered by evals → commit to git immediately

*Last updated: 2026-03-06*
