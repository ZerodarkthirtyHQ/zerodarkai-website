---
name: agent-delegation
description: Multi-agent coordination protocol for spawning, monitoring, and managing Dwight/Pam/Stanley sub-agents. Use when delegating tasks to sub-agents, tracking long-running agent jobs, or steering/killing stuck agents.
---

# Avatar: Agentic Delegation & Smart Monitoring

Protocol for coordinating sub-agents with automatic monitoring and clean completion handling.

---

## Core Delegation Protocol

### 1. Clear Task Definition
Always end a sub-agent task prompt with a completion signal:
```
"AgentName: on standby"
```
Example: *"Research BTC sentiment and report back. End your message with: Dwight: on standby"*

### 2. Smart Monitoring (Auto Cron)
The moment a sub-agent is spawned:
- Note the spawn time and expected runtime
- **Simple tasks:** flag if not done in 5 minutes
- **Complex tasks:** flag if not done in 10 minutes
- Check status with `subagents(action="list")`

When ALL sub-agents are done → stop monitoring.

### 3. Progress Updates
While waiting on a sub-agent, send Ben a status line at each check interval:
```
"Dwight update (3 min in): Still scanning crypto prices and news."
```

### 4. Guided Steer Protocol
If an agent exceeds expected runtime OR Ben asks for a status check:
1. Run `subagents(action="list")` to confirm they're still active
2. Identify the exact blockage (what step are they on?)
3. Use `subagents(action="steer", target="dwight", message="hint/clarification")` — give a concrete nudge WITHOUT taking over
4. Never solve it yourself — only guide

### 5. Completion Handling
When the completion signal is detected:
1. Confirm to Ben: `"Dwight: on standby ✅"`
2. Summarize results in bullets: what was done, where output lives

### 6. Error & Timeout Protocol
If sub-agent is unresponsive:
1. `subagents(action="steer")` with clarification request
2. Wait one interval
3. If still stuck: `subagents(action="kill", target="AgentName")`
4. Optionally respawn with a simplified task
5. Never leave a zombie agent running

---

## Agent Roster & Strengths

| Agent | Strengths | Use For |
|-------|-----------|---------|
| 🥬 Dwight | Market intel, crypto, news, research | Price checks, market analysis, product scouting |
| 🎨 Pam | Image gen, SVG, design, 3D assets | Product photos, mockups, laser files, graphics |
| 🧮 Stanley | Code, debugging, APIs, data pipelines | Building bots, fixing bugs, writing scripts |

---

## Example Delegation

**Ben:** "Have Stanley add the Kalshi API to the trade bot."

**Prison Mike:**
1. Spawn Stanley with task + completion signal:
   *"Read kalshi-bot/bot.py, implement the Kalshi v2 API endpoint. When done: Stanley: on standby"*
2. Note spawn time, set 10-min complex task timer
3. Send Ben: *"Stanley's on it. I'll check back in 10 min."*
4. At 5 min: `subagents(action="list")` — report status to Ben
5. On completion signal: confirm + bullet summary
6. If stuck at 10 min: steer with specific hint about Kalshi API docs

---

## Token Efficiency Rules
- Don't spawn a sub-agent for tasks Prison Mike can do in <2 minutes
- Kill idle agents immediately — never leave them running
- Only monitor actively — no permanent polling crons
- One agent per task type — don't parallelize unless tasks are truly independent
