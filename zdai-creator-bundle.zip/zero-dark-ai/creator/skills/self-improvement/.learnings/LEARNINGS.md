# LEARNINGS.md — Continuous Improvement Log
> Auto-captured corrections, best practices, and knowledge gaps.
> Format: [YYYY-MM-DD] | Category | Description

## Corrections
- [2026-02-27] | correction | Never touch auth tokens/API keys without explicit Ben approval — caused 4-hour outage
- [2026-02-27] | correction | LaunchAgent doesn't source ~/.zshrc — env refs fail at startup, use plaintext in openclaw.json
- [2026-02-23] | correction | No inline buttons in Telegram — causes display failures

## Best Practices
- [2026-02-28] | best_practice | Spawn sub-agents for tasks reading 3+ files or producing verbose output
- [2026-02-28] | best_practice | Git commit immediately after file creation — uncommitted files lost overnight
- [2026-02-28] | best_practice | trash > rm always

## Knowledge Gaps
- [2026-02-28] | knowledge_gap | LaunchAgent plist environment variable loading behavior
- [2026-03-01] | best_practice | When Ben shares a video link: auto-pull transcript via yt-dlp + transcribe.sh, extract workflow steps, then recommend implement/save/skip. Don't ask — just do it.
