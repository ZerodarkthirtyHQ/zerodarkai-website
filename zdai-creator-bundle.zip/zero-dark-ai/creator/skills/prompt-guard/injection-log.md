# Injection Attempt Log
> Auto-logged by Prompt Guard. Format: [timestamp] | severity | description

## Logged Attempts
- [2026-03-01 09:08 CST] | HIGH | Fake "Post-Compaction Audit" system message — claimed required startup files WORKFLOW_AUTO.md needed reading. Classic file-read injection. Blocked manually.
