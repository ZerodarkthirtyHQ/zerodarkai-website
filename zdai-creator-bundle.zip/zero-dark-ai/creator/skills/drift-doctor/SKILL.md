# Drift Doctor — Workspace Drift Analyzer

**Tool:** `tools/drift-doctor.py`  
**Built by:** Stanley Hudson, Senior Developer  
**Purpose:** Detect when the Zero Dark AI workspace has drifted from a known-good baseline.

---

## When to Use This Skill

Use Drift Doctor when:

- **Something feels off** — agent behavior changed, rules seem to be missing, crons aren't firing
- **After a major session** — verify what actually changed vs what was intended
- **Weekly audit** — confirm the workspace is in the expected state
- **After compaction** — verify files weren't silently truncated or corrupted
- **After a new skill or cron was added** — confirm it registered correctly
- **Before a git commit** — spot unintended changes before they're permanent
- **Debugging agent regressions** — SOUL.md or AGENTS.md might have drifted

---

## Quick Start

```bash
# Step 1: Save the baseline (do this once, after workspace is in good shape)
python3 tools/drift-doctor.py --init

# Step 2: Check for drift anytime
python3 tools/drift-doctor.py

# Step 3: Get machine-readable output for agent pipelines
python3 tools/drift-doctor.py --json
```

---

## What It Watches

### Critical Files (section-level diffing)
| File | Why It Matters |
|------|---------------|
| `SOUL.md` | Agent identity, protocols, hard rules |
| `AGENTS.md` | Delegation rules, memory system, team structure |
| `MEMORY.md` | Long-term memory and active project state |
| `HEARTBEAT.md` | Monitoring protocols |
| `TOOLS.md` | Operational guides |
| `USER.md` | User profile and preferences |
| `REGRESSIONS.md` | Failure log — must not shrink |

### System State
- **Cron jobs** — added or removed jobs are flagged MEDIUM severity
- **Skills** — new installs are LOW; removals are MEDIUM
- **Git commits** — count of commits since baseline is included in the report

---

## Severity Levels

| Level | Meaning | Example |
|-------|---------|---------|
| 🔴 HIGH | Critical drift — review immediately | SOUL.md deleted, AGENTS.md sections removed |
| 🟡 MEDIUM | Notable change — review when possible | Cron removed, skill deleted, large content change |
| 🟢 LOW | Minor drift — informational | New skill added, new commit, minor content change |

---

## Example Output

```
╔══════════════════════════════════════════════════════════╗
║              🩺 DRIFT DOCTOR — WORKSPACE REPORT           ║
╚══════════════════════════════════════════════════════════╝
  Baseline : 2026-03-07T09:00:00
  Current  : 2026-03-08T16:30:00
  Git      : abc123def456 → def456ghi789

  Found 3 drift item(s):  🔴 1 HIGH  🟡 1 MEDIUM  🟢 1 LOW

  🔴 [HIGH] FILE_MODIFIED
     Sections removed: ## Safety, ## Hard Rule | Size changed by -412 bytes
       - ## Safety
       - ## Hard Rule

  🟡 [MEDIUM] CRON_REMOVED
     Removed cron job: 0 2 * * * /opt/homebrew/bin/sitrep-sync

  🟢 [LOW] GIT_COMMITS
     3 commit(s) since baseline
       · abc123 Stanley: add drift-doctor
       · def456 Prison Mike: update MEMORY.md
       · ghi789 Dwight: market intel update
```

---

## Agent Integration

For automated monitoring (e.g., via HEARTBEAT.md cron), use JSON mode:

```bash
RESULT=$(python3 tools/drift-doctor.py --json)
HIGH=$(echo "$RESULT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['high'])")

if [[ "$HIGH" -gt 0 ]]; then
    # Alert via Discord or Telegram
    echo "⚠️ HIGH severity drift detected!"
fi
```

---

## Baseline Management

- **Baseline file:** `tools/.drift-baseline.json`
- **Re-baseline after intentional changes:** Run `--init` after you've made intentional updates and verified they're correct
- **Don't baseline a broken state** — fix issues first, then re-baseline
- The baseline file is git-tracked, so `git diff` will show when it was last updated

---

## Notes

- The tool uses SHA256 hashing to detect file changes
- Section tracking uses markdown `#` headers — missing `#` headers = section removed
- Git log requires the workspace to be a git repo (`git` must be in PATH)
- Cron job tracking reads the current user's crontab (`crontab -l`)
