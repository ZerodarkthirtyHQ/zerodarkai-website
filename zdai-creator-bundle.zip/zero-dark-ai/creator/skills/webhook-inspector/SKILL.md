# Webhook Inspector — Lightweight Webhook Logger & Proxy

**Tool:** `tools/webhook-inspector.py`  
**Built by:** Stanley Hudson, Senior Developer  
**Purpose:** Capture, inspect, replay, and proxy webhook payloads for debugging integrations.

---

## When to Use This Skill

Use Webhook Inspector when:

- **Debugging a Discord webhook** — see exactly what payload was sent
- **Testing a cron job delivery** — confirm the cron fired and what it sent
- **Debugging external integrations** — capture raw payloads from third-party services
- **Developing a new webhook handler** — intercept before routing to your real endpoint
- **Replaying a missed webhook** — re-fire a captured payload without triggering the source again
- **Auditing what hit your server** — review all incoming requests with timestamps

---

## Quick Start

### Start in capture-only mode (no forwarding)
```bash
python3 tools/webhook-inspector.py
# → Listening on port 9999
# → All webhooks captured to tools/webhook-logs/
# → Returns 200 {"status":"captured","id":"..."} to sender
```

### Start with proxy forwarding
```bash
python3 tools/webhook-inspector.py --proxy https://your-real-endpoint.com/webhook
# → Captures payload AND forwards to real destination
# → Returns real destination's response to sender
```

### List all captured webhooks
```bash
python3 tools/webhook-inspector.py --list
```

### View full payload of a specific webhook
```bash
python3 tools/webhook-inspector.py --view 20260308-163000-abc123
```

### Replay a captured webhook
```bash
python3 tools/webhook-inspector.py --replay 20260308-163000-abc123 --proxy https://real.endpoint.com/
```

### Delete all logs
```bash
python3 tools/webhook-inspector.py --clear
```

---

## How It Works

```
External Service
      │
      ▼
  Port 9999          ← point webhooks here
      │
      ├─→ Save to tools/webhook-logs/<id>.json
      │
      ├─→ [Optional] Forward to --proxy destination
      │
      └─→ Return response to sender
```

### Log file format
Each captured webhook is saved as a JSON file:
```json
{
  "id": "20260308-163000-abc123",
  "timestamp": "2026-03-08T16:30:00.123456",
  "source_ip": "127.0.0.1",
  "method": "POST",
  "path": "/webhook/discord",
  "headers": { "Content-Type": "application/json", ... },
  "body_raw": "{\"event\": \"message\", ...}",
  "body_parsed": { "event": "message", ... },
  "size_bytes": 284
}
```

---

## Log Rotation

- Logs stored in `tools/webhook-logs/`
- Maximum **500 logs** kept (oldest deleted automatically)
- Log IDs are timestamp-based: `YYYYMMDD-HHMMSS-<6 hex chars>`

---

## Common Use Cases

### Debugging a Discord webhook
1. Temporarily point Discord to `http://your-machine:9999/webhook`
2. Run inspector: `python3 tools/webhook-inspector.py`
3. Trigger the Discord event
4. Inspect: `python3 tools/webhook-inspector.py --list`
5. View payload: `python3 tools/webhook-inspector.py --view <id>`

### Debugging a cron job
1. Change cron to POST to `http://localhost:9999/cron-ping`
2. Run inspector in background: `python3 tools/webhook-inspector.py &`
3. Wait for cron to fire
4. Check if it arrived: `python3 tools/webhook-inspector.py --list`

### Setting up as a proxy (staging)
```bash
# All webhooks → inspect → forward to real handler
python3 tools/webhook-inspector.py --proxy http://localhost:8080/real-handler
```

### Replaying missed webhooks during an outage
```bash
# 1. Get the ID of the missed webhook
python3 tools/webhook-inspector.py --list

# 2. Replay it to the handler
python3 tools/webhook-inspector.py --replay 20260308-020000-xyz789 \
    --proxy http://localhost:8080/real-handler
```

---

## Running in Background

```bash
# Start in background, log to file
nohup python3 tools/webhook-inspector.py > /tmp/webhook-inspector.log 2>&1 &
echo "Inspector PID: $!"

# Stop it
kill $(lsof -ti:9999)
```

---

## Notes

- Port **9999** is hardcoded (change `PORT` constant in script if needed)
- Supports: POST, GET, PUT, PATCH, DELETE
- Body is parsed as JSON if possible; raw bytes stored as fallback
- Replay re-sends with original headers (minus `Host` and `Content-Length`)
- `--list` shows newest 50; all logs are available in `tools/webhook-logs/`
