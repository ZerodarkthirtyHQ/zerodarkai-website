# Env Manager — Safe .env File Manager

**Tool:** `/opt/homebrew/bin/envmgr` (CLI)  
**Built by:** Stanley Hudson, Senior Developer  
**Purpose:** Safely read, write, and audit `.env` files without ever exposing full secret values.

---

## When to Use This Skill

Use `envmgr` when:

- **Adding or updating API keys** — set secrets without accidentally logging them
- **Auditing what keys are configured** — `list` shows all keys with masked values
- **Checking for empty/missing values** — `check` catches misconfigurations before they break things
- **Finding .env files across a project** — `scan` locates all env files in a directory tree
- **Debugging "why isn't this key working"** — `get` shows masked value to confirm it's set
- **Removing stale keys** — `remove` cleans up without opening the file manually

---

## Commands

### List all keys (values masked)
```bash
envmgr list
envmgr list --file /path/to/project/.env
```

### Get a specific key's value (masked)
```bash
envmgr get OPENAI_API_KEY
envmgr get DISCORD_TOKEN --file ~/projects/mybot/.env
```

### Add or update a key
```bash
envmgr set OPENAI_API_KEY "sk-abc123..."
envmgr set DATABASE_URL "postgres://user:pass@host/db" --file .env
```

### Remove a key
```bash
envmgr remove OLD_API_KEY
envmgr remove DEPRECATED_TOKEN --file .env
```

### Check all keys have non-empty values
```bash
envmgr check
envmgr check --file ~/projects/app/.env
```

### Find all .env files
```bash
envmgr scan                    # Scan home directory
envmgr scan ~/projects         # Scan specific directory
envmgr scan /Users/ben/code    # Full path
```

---

## Security Model

**Values are NEVER printed in full.**

Masking format: first 4 chars + `***` + last 3 chars

| Original | Masked |
|----------|--------|
| `sk-abc123defxyz` | `sk-a***xyz` |
| `ghp_ABCDEFGHIJKLM` | `ghp_***LMN` |
| `short` | `sh***rt` |
| `ab` | `***` |

- `envmgr get` returns the masked value — useful to confirm a key is set without exposing it
- No commands log the full value to stdout, stderr, or any file
- The `.env` file itself is never printed; only individual keys

---

## Default File

All commands default to:
```
~/.openclaw/workspace-prison-mike/.env
```

Override with `--file` on any command.

---

## Example Workflow

```bash
# 1. Check what keys are currently set
envmgr list

# 2. Verify a specific key looks right
envmgr get OPENAI_API_KEY

# 3. Add a new key
envmgr set ANTHROPIC_API_KEY "sk-ant-..."

# 4. Run a health check before deploying
envmgr check

# 5. Find all env files in a project to audit them
envmgr scan ~/my-project
```

---

## Notes

- `envmgr set` creates the file if it doesn't exist (including parent directories)
- Comments (lines starting with `#`) and blank lines are preserved in `list` output filtering but left in the file
- `remove` uses `sed` — safe for macOS (uses `sed -i ''`) and Linux
- `scan` skips `node_modules`, `.git`, and `__pycache__` directories automatically
- Works with quoted values (`KEY="value"` and `KEY='value'`) — quotes are stripped for masking but left in file
