---
name: content-creator
description: "Create SEO-optimized marketing content with consistent brand voice. Use when writing blog posts, creating social media content, establishing brand voice, optimizing content for SEO, or planning content calendars."
category: marketing
---

# Content Creator

Professional-grade brand voice analysis, SEO optimization, and platform-specific content frameworks.

## When to Use

Use this skill when writing blog posts, creating social media content, establishing brand voice, optimizing content for SEO, or planning content calendars.

## Core Workflows

### Establishing Brand Voice

1. **Analyze Existing Content** — feed samples to extract voice profile
2. **Define Voice Attributes** — select from brand personality archetypes:
   - Primary and secondary archetypes
   - 3-5 tone attributes (formal/casual, warm/authoritative, etc.)
   - Document in brand guidelines
3. **Create Voice Samples** — write 3 sample pieces, refine for consistency

### Creating SEO-Optimized Blog Posts

1. **Keyword Research** (use `web_search` to validate demand)
   - Primary keyword: 500–5,000/mo search volume
   - 3-5 secondary keywords
   - 10-15 LSI keywords

2. **Content Structure**
   - Keyword in title, first paragraph, 2-3 H2s
   - 1,500–2,500 words for comprehensive coverage
   - Clear intro hook → problem → solution → CTA

3. **Optimization Check**
   - Keyword density: 1-3% for primary
   - Proper heading structure (H1 → H2 → H3)
   - Internal + external links
   - Meta description (150-160 chars)

### Social Media Content Creation

**Platform-specific guidelines:**

| Platform | Ideal Length | Key Elements |
|----------|-------------|--------------|
| Twitter/X | 280 chars | Hook, no fluff |
| LinkedIn | 150-300 words | Professional tone, story |
| Instagram | 125-150 chars visible | Emotion-first, hashtags |
| Threads | Conversational | Authentic, no-polish |

**Workflow:**
1. Start with core message / blog post thesis
2. Adapt for each platform's format
3. Adjust tone to match platform audience

### Content Calendar Planning

**40/25/25/10 Content Pillar Ratio:**
- 40% Educational / value
- 25% Entertaining / relatable
- 25% Promotional / product
- 10% Community / engagement

**Monthly template:**
```
Week 1: [Theme] — [Platform distribution]
Week 2: [Theme] — [Platform distribution]
Week 3: [Theme] — [Platform distribution]
Week 4: [Theme] — [Platform distribution]
```

## Content Creation Process

1. Start with audience need/pain point
2. Research before writing (use `web_search`)
3. Create outline using templates
4. Write first draft without self-editing
5. Optimize for SEO
6. Edit for brand voice
7. Proofread and fact-check
8. Platform-optimize before publishing
9. Schedule strategically

## Quality Indicators

- SEO score: aim for 75+/100
- Readability appropriate for audience
- Consistent brand voice throughout
- Clear value proposition
- Actionable takeaways
- Proper visual formatting

## Common Pitfalls

- Writing before researching keywords
- Ignoring platform-specific requirements
- Inconsistent brand voice
- Over-optimizing (keyword stuffing)
- Missing clear CTAs
- Publishing without proofreading

## Performance Metrics

**Content:** Organic traffic, time on page, bounce rate, social shares, backlinks

**Engagement:** Comments, email CTR, social engagement rate, downloads

**Business:** Leads generated, conversion rate, revenue attribution, ROI per piece

## OpenClaw Integration

- Use `web_search` for keyword research and competitor content analysis
- Use `web_fetch` to pull competitor articles for gap analysis
- Use `exec` to run local Python SEO/readability scripts if available
