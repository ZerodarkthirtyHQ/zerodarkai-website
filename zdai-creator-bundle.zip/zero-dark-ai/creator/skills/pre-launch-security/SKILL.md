---
name: pre-launch-security
description: Run a pre-launch security audit on any web app before shipping. Use when a project is near launch, before deploying to production, or when reviewing a vibe-coded app for security gaps. Triggers on "pre-launch", "ready to ship", "security check", "audit before launch", "is this safe to deploy".
---

# Pre-Launch Security Checklist

> Source: @PrajwalTomar_ (758 likes) — "Takes 30 minutes. Saves you from disaster."
> Mandatory before ANY app goes live. FightClaw, Privacy Shield, web agency client sites — all of them.

## The 8-Point Checklist

### 1. ✅ Rate Limits
- API endpoints must have rate limiting (per IP, per user, per token)
- Auth endpoints: strict limits (5 attempts/min max)
- Public endpoints: limit by IP
- Tools: Upstash Rate Limit, Vercel Edge Config, nginx rate_limit_req
- **Test:** hammer your own endpoints. If it doesn't reject after 10 rapid requests, it's broken.

### 2. ✅ Row Level Security (RLS)
- If using Supabase/Postgres: RLS must be ENABLED on every table with user data
- Default deny — whitelist what's allowed, not blacklist what's blocked
- Test: try to access another user's data with a valid but different auth token
- **Common miss:** developers disable RLS for speed during dev and forget to re-enable

### 3. ✅ CAPTCHA on Auth + Forms
- Login, signup, password reset, contact forms — all need CAPTCHA
- Use Cloudflare Turnstile (free, privacy-friendly) or hCaptcha
- Protects against: credential stuffing, spam bots, scraping
- **Test:** attempt 50 rapid form submissions. Should block by #3-5.

### 4. ✅ Server-Side Validation
- NEVER trust client-side validation alone
- Validate ALL inputs on the server: types, lengths, formats, ranges
- Sanitize user input before DB writes (prevent SQL injection, XSS)
- Use a schema validation library (Zod, Joi, Yup)
- **Test:** send malformed data directly via curl/Postman — bypass the UI entirely.

### 5. ✅ API Keys Secured
- No API keys in frontend code — ever
- No API keys in git history (use `git log --all -S "sk-"` to check)
- All 3rd party keys go through backend proxy endpoints
- Rotate any key that was ever exposed
- **Test:** `grep -r "sk-\|AIza\|Bearer" ./src` — if it returns results, you have a problem.

### 6. ✅ Env Vars Set Properly
- `.env` files in `.gitignore` — always
- Production env vars set in hosting dashboard (Vercel, Railway, etc.) — not in code
- Separate keys for dev/staging/production — never share prod keys locally
- **Test:** `git status` should never show `.env` as untracked (means it was never committed)

### 7. ✅ CORS Restrictions
- Don't use `Access-Control-Allow-Origin: *` in production
- Whitelist only your actual domains
- Different origins for dev/prod
- **Test:** make a fetch request from a random domain to your API — should get blocked.

### 8. ✅ Dependency Audit
- Run `npm audit` or `bun audit` before launch
- Fix all CRITICAL and HIGH severity vulnerabilities
- Update outdated packages with known CVEs
- **Test:** `npm audit --audit-level=high` — zero tolerance for high/critical.

---

## Quick Run Commands

```bash
# Check for exposed secrets in code
grep -r "sk-\|AIza\|Bearer\|api_key\|secret" ./src --include="*.js" --include="*.ts"

# Check git history for leaked keys
git log --all -p | grep -i "api_key\|secret\|password" | head -20

# Dependency audit
npm audit --audit-level=high

# Check .env not tracked
git ls-files | grep ".env"
```

## Launch Gate
All 8 must be ✅ before any app goes live. No exceptions.

If any item is ❌ — fix it before shipping. A broken app at 10 users is recoverable. A breached app at 10 users is a lawsuit.
