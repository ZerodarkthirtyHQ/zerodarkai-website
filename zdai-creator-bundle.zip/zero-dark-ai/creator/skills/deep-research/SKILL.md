---
name: deep-research
description: "Execute autonomous multi-step research using Google Gemini Deep Research Agent. Use for market analysis, competitive landscaping, literature reviews, technical research, due diligence. Takes 2-10 minutes per task."
category: research
---

# Deep Research (Gemini Agent)

Run autonomous research tasks that plan, search, read, and synthesize information into comprehensive reports.

## When to Use

- Market analysis and competitive landscaping
- Literature reviews and technical research
- Due diligence on companies, people, or technologies
- Historical research and timelines
- Comparative analysis (frameworks, products, technologies)
- Any topic needing a detailed, cited report

## Requirements

- Python 3.8+
- `pip install httpx` (or `pip install -r requirements.txt`)
- `GEMINI_API_KEY` environment variable set

**Setup:**
```bash
export GEMINI_API_KEY=your-api-key-here
```

The GEMINI_API_KEY is available in `~/.zshrc` — check there first.

## Usage

### Start a research task
```bash
python3 scripts/research.py --query "Research the current state of DeFi lending protocols"
```

### With structured output format
```bash
python3 scripts/research.py --query "Compare Base vs Ethereum for DeFi development" \
  --format "1. Executive Summary\n2. Comparison Table\n3. Recommendations"
```

### Stream progress in real-time
```bash
python3 scripts/research.py --query "Analyze UV laser engraver market" --stream
```

### Start without waiting (background)
```bash
python3 scripts/research.py --query "Research topic" --no-wait
```

### Check status of running research
```bash
python3 scripts/research.py --status <interaction_id>
```

### Wait for completion
```bash
python3 scripts/research.py --wait <interaction_id>
```

### Continue from previous research
```bash
python3 scripts/research.py --query "Elaborate on point 2" --continue <interaction_id>
```

### List recent research
```bash
python3 scripts/research.py --list
```

## Output Formats

- **Default**: Human-readable markdown report
- **JSON** (`--json`): Structured data for programmatic use
- **Raw** (`--raw`): Unprocessed API response

## Cost & Time

| Metric | Value |
|--------|-------|
| Time | 2-10 minutes per task |
| Cost | $2-5 per task (varies by complexity) |
| Token usage | ~250k-900k input, ~60k-80k output |

## Workflow

1. User requests research → Run `--query "..."`
2. Inform user of estimated time (2-10 minutes)
3. Monitor with `--stream` or poll with `--status`
4. Return formatted results
5. Use `--continue` for follow-up questions

## OpenClaw Integration

- Use `exec` with `pty=false` to run research scripts in background
- Use `web_search` for quick lookups before committing to full deep research
- Pipe output to files for QMD indexing: `python3 scripts/research.py --query "..." > research/output.md`
- For faster, cheaper alternative: use `web_search` + `web_fetch` chain manually

## Exit Codes

- **0**: Success
- **1**: Error (API error, config issue, timeout)
- **130**: Cancelled by user (Ctrl+C)
