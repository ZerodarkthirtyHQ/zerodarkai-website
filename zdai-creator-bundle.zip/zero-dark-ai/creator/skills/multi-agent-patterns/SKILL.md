---
name: multi-agent-patterns
description: "Master orchestrator, peer-to-peer, and hierarchical multi-agent architectures. Use when designing agent systems, debugging coordination failures, or scaling tasks beyond single-agent context limits."
category: ai
---

# Multi-Agent Architecture Patterns

Multi-agent architectures distribute work across multiple LLM instances, each with its own context window. The critical insight: **sub-agents exist primarily to isolate context, not to simulate org chart roles.**

## When to Use Multi-Agent

- Single-agent context limits constrain task complexity
- Tasks decompose naturally into parallel subtasks
- Different subtasks need different tool sets or system prompts
- Scaling agent capabilities beyond single-context limits

**Token reality check:**

| Architecture | Token Multiplier | Use Case |
|-------------|-----------------|----------|
| Single agent chat | 1× | Simple queries |
| Single agent with tools | ~4× | Tool-using tasks |
| Multi-agent system | ~15× | Complex research/coordination |

## Three Dominant Patterns

### Pattern 1: Supervisor / Orchestrator

Central agent controls, delegates to specialists, synthesizes results.

```
User Query → Supervisor → [Specialist A, Specialist B, Specialist C] → Aggregation → Output
```

**Use when:** Complex tasks with clear decomposition, requiring coordination across domains, human oversight is important.

**The Telephone Game Problem:** Supervisors paraphrase sub-agent responses incorrectly, losing fidelity. **Fix:** implement direct pass-through so sub-agents respond directly to users when appropriate.

**In OpenClaw:** Use `subagents` tool for spawn/steer/kill. Supervisor is the main agent session; sub-agents are spawned workers.

### Pattern 2: Peer-to-Peer / Swarm

No central control — agents communicate directly via explicit handoff protocols.

```python
def handle_customer_request(request):
    if request.type == "billing":
        return transfer_to(billing_agent)
    elif request.type == "technical":
        return transfer_to(technical_agent)
    else:
        return handle_general(request)
```

**Use when:** Flexible exploration tasks, emergent requirements, tasks where rigid planning fails.

**In OpenClaw:** Implemented via Dwight/Pam/Stanley/Creed each handling their domain. Prison Mike routes.

### Pattern 3: Hierarchical

Layered abstraction: strategy → planning → execution.

```
Strategy Layer (Goal Definition)
    → Planning Layer (Task Decomposition)
        → Execution Layer (Atomic Tasks)
```

**Use when:** Large-scale projects, enterprise workflows, tasks needing both high-level planning and detailed execution.

## Context Isolation — The Core Principle

**Full context delegation:** Sub-agent gets complete context. Maximum capability, defeats isolation purpose.

**Instruction passing:** Sub-agent gets only task instructions. Maintains isolation, limits flexibility.

**File system memory:** Agents read/write shared files. Enables coordination without context passing. Best for complex multi-step work.

## Consensus & Coordination

### The Sycophancy Problem
Multi-agent discussions devolve into consensus on false premises. Agents agree to agree.

**Fix:** Debate protocols — require agents to critique each other's outputs. Adversarial critique yields higher accuracy than collaborative consensus.

### Weighted Voting
Weight agent votes by confidence or expertise. Weak model + high confidence ≠ strong model reasoning.

## Failure Modes & Mitigations

| Failure | Cause | Mitigation |
|---------|-------|-----------|
| Supervisor bottleneck | Supervisor context saturates | Output schema constraints, checkpointing |
| Coordination overhead | Too much inter-agent communication | Batch results, async patterns |
| Divergence | Agents drift from objectives | Clear boundary definitions, convergence checks |
| Error propagation | Bad output passes downstream | Validate before passing, retry with circuit breakers |
| Telephone game | Supervisor paraphrases incorrectly | Direct pass-through mechanism |

## OpenClaw Agent Roster Application

```
Prison Mike (Supervisor/Orchestrator)
├── Dwight (Market Intelligence — research tasks)
├── Pam (Creative Director — design/content tasks)
├── Stanley (Senior Developer — code tasks)
└── Creed (Security — audit tasks)

On-demand spawns:
├── Oscar (Data analysis)
├── Toby (Deep research)
├── Ryan (Content writing)
└── Kelly (Social media)
```

**Delegation rules:**
- Quick tasks (<2 min): Main agent handles
- Research, code, content, analysis: Spawn sub-agent
- Haiku: cron jobs, simple research
- Sonnet: complex reasoning
- Opus: hard problems, architecture

## Design Guidelines

1. Design for **context isolation** as the primary benefit
2. Choose pattern based on **coordination needs**, not organizational metaphor
3. Implement **explicit handoff protocols** with state passing
4. Use **debate protocols** for consensus on important decisions
5. Monitor for **supervisor bottlenecks** and checkpoint
6. **Validate outputs** before passing between agents
7. Set **time-to-live limits** to prevent infinite loops
8. Test **failure scenarios** explicitly

## Research Team Example

```
Supervisor
├── Researcher (web search, document retrieval)
├── Analyzer (data analysis, statistics)
├── Fact-checker (verification, validation)
└── Writer (report generation, formatting)
```

## Related Skills
- `context-compression` — Managing context before it blows up
- `context-degradation` — Diagnosing context failures
- `tool-design` — Tool specialization per agent
- `agent-delegation` — OpenClaw-specific delegation protocol
