---
name: seo-keyword-strategist
description: "Analyze content for semantic SEO opportunities: keyword density, entity analysis, LSI keywords, over-optimization detection, and search intent mapping. Use when optimizing pages, planning content, or auditing existing SEO."
category: marketing
---

# SEO Keyword Strategist

Semantic keyword optimization — keyword density, entity mapping, LSI generation, and search intent analysis.

## When to Use

- Optimizing existing content for organic search
- Planning new content around keyword opportunities
- Auditing pages for over-optimization or under-optimization
- Building topical authority through entity-rich content
- Identifying People Also Ask (PAA) and featured snippet opportunities

## Focus Areas

- Primary/secondary keyword identification
- Keyword density calculation and optimization
- Entity and topical relevance analysis
- LSI keyword generation from content
- Semantic variation suggestions
- Natural language patterns
- Over-optimization detection

## Keyword Density Guidelines

| Type | Target Density | Notes |
|------|---------------|-------|
| Primary keyword | 0.5–1.5% | Natural placement throughout |
| Secondary keywords | 0.3–0.8% | Support without stuffing |
| LSI/semantic terms | Organic | Use naturally |

**Over-optimization signals:** Same phrase repeated mechanically, unnatural sentence construction, keyword in every H2.

## Entity Analysis Framework

1. **Identify primary entity relationships** — What is this page fundamentally about?
2. **Map related entities and concepts** — People, places, products, concepts that co-occur
3. **Analyze competitor entity usage** — What topics do ranking pages cover? (use `web_search`)
4. **Build topical authority signals** — Cluster related content around entity hubs
5. **Create entity-rich content sections** — Define, explain, and contextualize key entities

## Keyword Research Workflow

### Step 1: Extract Current Usage
Analyze provided content for:
- Current keyword occurrences and density %
- Heading structure (H1 → H2 → H3)
- Missing keyword placements

### Step 2: Determine Search Intent

| Intent Type | Signals | Content Format |
|------------|---------|---------------|
| Informational | "what is", "how to", "why" | Blog, guide, explainer |
| Navigational | Brand name + modifier | Landing page |
| Commercial | "best", "vs", "review" | Comparison, listicle |
| Transactional | "buy", "price", "near me" | Product/service page |

### Step 3: Generate LSI Keywords
For any topic, develop 20-30 semantic variations:
- Synonym variations of primary keyword
- Related concepts and co-occurring terms
- Question forms ("how to X", "what is X")
- Modifier variations (best, top, free, cheap, professional)

### Step 4: Keyword Placement Recommendations

**Priority placements:**
1. Title tag (primary keyword, front-loaded)
2. H1 heading (primary keyword)
3. First 100 words (natural inclusion)
4. 2-3 H2 headings (primary + secondary)
5. Image alt text
6. Meta description (primary keyword + CTA)
7. URL slug (primary keyword, hyphens)

## Output Format

```
## Keyword Strategy Package

**Primary:** [keyword] (target X.X% density, current Y.Y%)
**Secondary:** [keyword 1], [keyword 2], [keyword 3]
**LSI Keywords:** [20-30 semantic variations]
**Entities:** [related concepts to include]
**Search Intent:** [informational/commercial/transactional]

## Optimization Checklist
- [ ] Primary keyword in title (front-loaded)
- [ ] Primary keyword in first paragraph
- [ ] 2-3 H2s include primary/secondary keywords
- [ ] Meta description written (150-160 chars)
- [ ] Internal links added (2-3 minimum)
- [ ] External authority links added (1-2)
- [ ] Image alt text optimized
- [ ] URL slug contains primary keyword

## Issues Found
- [Over-optimization warning if applicable]
- [Missing placements]
- [Keyword cannibalization risks]

## Advanced Opportunities
- PAA questions to target: [list]
- Featured snippet opportunities: [list]
- Keyword clusters for topic hubs: [list]
```

## OpenClaw Integration

- Use `web_search` to validate keyword search volumes and competition
- Use `web_search` to find competitor pages ranking for target keywords
- Use `web_fetch` to analyze top-ranking competitor content structure
- Use `web_search "[keyword] site:reddit.com OR site:quora.com"` for PAA/question research

## Related Skills
- `content-creator` — Writing the actual content
- `competitor-alternatives` — Competitor page keyword strategy
- `free-tool-strategy` — Tool-based keyword targeting
