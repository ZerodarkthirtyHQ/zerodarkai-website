# SKILLS.md — The Contractor Skill Bundle

> These 7 skills ship with every copy of The Contractor. Selected for freelancers, independent contractors, and project-based operators.
> Install script handles installation automatically.

---

## Bundled Skills

### 1. `apple-reminders`
**Why it's included:** Deadlines, client check-ins, invoice follow-ups, and billing cycles — set them once in plain English and never miss them.  
**Contractor use case:** "Remind me Tuesday to follow up on the invoice for the Henderson project" or "Set a reminder for the 1st of every month to send recurring invoices."

---

### 2. `apple-notes`
**Why it's included:** Project notes, meeting summaries, client preferences, change orders, and SOPs — all captured and accessible without leaving the conversation.  
**Contractor use case:** "Save the scope change we agreed to on the Rivera project — 2 extra revision rounds included" or "Log that Thompson prefers Slack over email and hates status meetings."

---

### 3. `summarize`
**Why it's included:** Digest long client briefs, contracts, SOW documents, and project specs fast. Turn a 12-page document into 5 actionable bullet points.  
**Contractor use case:** "Summarize this client brief and tell me if there's any scope ambiguity I need to clarify before signing off" or "Pull the key deliverables from this 15-page RFP."

---

### 4. `content-creator`
**Why it's included:** Client proposals, project update emails, case study write-ups, and your freelance website copy — all written professionally in your voice.  
**Contractor use case:** "Write a project proposal for a logo redesign — 3-week timeline, $2,500, includes 3 revision rounds" or "Draft a case study for the Thompson project — focused on the results we delivered."

---

### 5. `weather`
**Why it's included:** Field contractors and project managers need weather awareness for on-site scheduling, crew deployment, and client communication.  
**Contractor use case:** "Will weather affect the outdoor portion of the job this week?" or "It's going to rain Thursday–Friday — draft a message to the client about adjusting the schedule."

---

### 6. `nano-banana-pro`
**Why it's included:** Generate professional portfolio images, mockups, proposal cover graphics, and social proof visuals — no designer needed.  
**Contractor use case:** "Create a before/after comparison graphic for my portfolio showcasing the kitchen renovation" or "Generate a professional LinkedIn cover image for a freelance web developer."

---

### 7. `seo-keyword-strategist`
**Why it's included:** Contractors who blog, post on LinkedIn, or run a service site benefit from SEO-optimized content to generate inbound leads passively.  
**Contractor use case:** "What keywords should I target on my freelance copywriting website to rank for local clients?" or "Optimize my LinkedIn headline and about section for SEO."

---

## Installation

These are installed automatically by `install.sh`. To install manually:

```bash
# Global skills (pre-installed with OpenClaw):
# apple-reminders, apple-notes, summarize, weather, nano-banana-pro

# Workspace-local skills (copy from bundle):
cp -r ./skills/content-creator ~/.openclaw/workspace-YOUR-NAME/skills/
cp -r ./skills/seo-keyword-strategist ~/.openclaw/workspace-YOUR-NAME/skills/
```

---

## Skills NOT Included (available as add-ons)

| Skill | Why it's an add-on |
|-------|-------------------|
| `cmc-mcp` | Crypto data — not relevant for most contractors |
| `gog` | Google Workspace — useful add-on for G-Suite-heavy contractors |
| `github` | Developer-focused add-on for software contractors |

> Add-on skills available at zerodarkAI.com/packs
