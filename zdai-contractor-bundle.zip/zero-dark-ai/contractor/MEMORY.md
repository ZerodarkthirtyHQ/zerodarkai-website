# MEMORY.md — Agent Memory

> This file is your agent's long-term brain. Pre-seeded with smart defaults for freelancers and contractors.
> Fill in the [BRACKETED] sections after completing your USER.md.
> Your agent will continue adding to this file automatically as it learns your preferences.

---

## Business Context
- **Business/Name:** [BUSINESS NAME]
- **Owner:** [OWNER NAME]
- **Service(s):** [SERVICES]
- **Rate:** [HOURLY RATE or PROJECT RATE]
- **Target monthly revenue:** [AMOUNT]

## Active Projects
| Project | Client | Budget | Deadline | Status | Hours Logged | Hours Remaining |
|---------|--------|--------|----------|--------|-------------|-----------------|
| | | | | | | |

## Client Roster
| Client | Project History | Payment History | Notes |
|--------|----------------|-----------------|-------|
| | | | |

## Invoicing Rules
- **Payment terms:** [e.g. 50% upfront, 50% on delivery / Net 15]
- **Invoice tool:** [FreshBooks / Wave / custom]
- **Follow-up schedule:** 7 days late = reminder, 14 days = firm email, 21 days = call + pause work
- **Change order rule:** All scope changes in writing before work begins. No exceptions.

## Time Tracking
- **Billable vs non-billable target:** [e.g. 80% of hours billable]
- **Minimum billing increment:** [e.g. 15 min / 30 min / 1 hour]
- **How you track time today:** [tool or method]

## Owner Preferences
- **Client communication style:** [e.g. weekly updates via email]
- **Response time promise to clients:** [e.g. 24 hours on business days]
- **Scope creep trigger:** [e.g. anything beyond initial brief = automatic change order]
- **[ADD YOUR OWN RULES HERE]**

---

## Pre-Seeded Best Practices (Freelance & Contracting)

### Protecting Your Time & Money
- Always get 50% upfront from new clients — if they balk, they're a flight risk
- Change orders protect you AND the client — frame them as a service, not a defense
- Track every minute you work — you cannot optimize what you don't measure
- Your hourly rate needs to include taxes, benefits, vacation, and downtime — most freelancers underprice by 30%

### Project Management
- Scope of work in writing before project starts — verbal agreements pay nothing
- Break every project into milestones with partial payments — reduces risk and increases motivation
- Weekly 15-min check-in calls with active clients prevent 80% of surprises
- If feedback rounds aren't defined up front, you'll do them infinitely

### Client Communication
- Proactive updates beat reactive damage control every time
- "Any questions?" is a weak closing line — tell them the next step instead
- Clients who go quiet are planning to cancel, complain, or both
- Always deliver one day before the deadline — buffer is your reputation

### Finding Work
- Best referral moment: 2 days after project closes when client is happiest
- Your portfolio page should show 3 things: problem, your solution, result
- Specialization beats generalization for both rates and referrals
- LinkedIn headline = "I help [who] achieve [outcome]" — not your job title

---

*Last updated: [auto-updated by agent]*
