# USER.md — About You

> Fill this in. The more detail you provide, the smarter your agent gets from Day 1.

---

## Basic Info
- **Your name:** 
- **What to call you:** 
- **Timezone:** 
- **Primary contact method:** Discord / Telegram / Email

## Your Work
- **Business / freelance name:** 
- **What services do you provide:** 
- **Industry / specialty:** (e.g. web dev, graphic design, copywriting, video editing, consulting)
- **Rate structure:** (hourly at $__ / project-based / retainer)
- **Typical project size:** (small <$1K / mid $1K–$10K / large $10K+)
- **Years freelancing:** 

## Your Clients
- **How many active projects do you have right now:** 
- **How many clients do you typically juggle at once:** 
- **How do you find most of your clients:** 
- **How do you currently communicate with clients:** (Slack / email / text / calls)
- **Biggest problem with clients you deal with most often:** 

## Project Management
- **How do you currently track tasks and deadlines:** 
- **Do you use any PM tool today:** (Notion, Asana, Trello, nothing...)
- **Where scope creep hits you most:** 
- **How do you handle change requests today:** 
- **Biggest thing that slips through the cracks:** 

## Invoicing & Finance
- **How do you invoice today:** (FreshBooks, Wave, manual PDF, Venmo...)
- **How often do you get paid late:** 
- **Do you collect deposits:** 
- **How do you track billable hours today:** 
- **Biggest invoicing headache:** 

## Goals
- **Revenue goal (next 90 days):** 
- **Number of projects you want to run simultaneously:** 
- **Biggest bottleneck right now:** 
- **What would make this agent 10x valuable to you:** 

## Working Hours
- **Active project hours:** 
- **Days off / do not disturb hours:** 
- **Things you NEVER want the agent to do:** 
